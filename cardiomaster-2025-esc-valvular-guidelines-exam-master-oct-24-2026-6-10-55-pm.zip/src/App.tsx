import React, { useState } from 'react';
import { Header } from './components/Header';
import { GuidelineLegend } from './components/GuidelineLegend';
import { FlowchartPanel } from './components/FlowchartPanel';
import { ScoringMatrixPanel } from './components/ScoringMatrixPanel';
import { ExamBookletPanel } from './components/ExamBookletPanel';
import { DseSimulatorCard } from './components/DseSimulatorCard';
import { NumberLinePanel } from './components/NumberLinePanel';
import { ExamTrapsPanel } from './components/ExamTrapsPanel';
import { PatientTriageSimulator } from './components/PatientTriageSimulator';
import { OtherModulesView } from './components/OtherModulesView';
import { PrintableNotes } from './components/PrintableNotes';
import { RecommendationClass } from './types/cardiology';
import { GitBranch, Table, FileSpreadsheet, BookmarkCheck, AlertTriangle, ArrowRight, ShieldCheck, HeartHandshake } from 'lucide-react';

export default function App() {
  const [currentTab, setCurrentTab] = useState<'severeAS' | 'aorticRegurg' | 'mitralRegurg' | 'simulator' | 'examBooklet'>('severeAS');
  const [activePanel, setActivePanel] = useState<number>(1);
  const [selectedLegendClass, setSelectedLegendClass] = useState<RecommendationClass | 'All'>('All');
  const [isPrintModalOpen, setIsPrintModalOpen] = useState<boolean>(false);

  const panels = [
    { id: 1, title: 'Panel 1: Decision Flowchart', icon: GitBranch, subtitle: 'Triage & branching logic' },
    { id: 2, title: 'Panel 2: Scoring Matrix', icon: Table, subtitle: 'Tables 1 & 2' },
    { id: 3, title: 'Panel 3: Exam Visuals & DSE', icon: FileSpreadsheet, subtitle: 'Lined paper & DSE card' },
    { id: 4, title: 'Panel 4: Memory Anchors', icon: BookmarkCheck, subtitle: 'V-C-B-L-E & Number Line' },
    { id: 5, title: 'Panel 5: Exam Traps & Quiz', icon: AlertTriangle, subtitle: 'Top 5 pitfalls & test' },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900">
      {/* 3-Zone Top Bar Navigation */}
      <Header
        currentTab={currentTab}
        onSelectTab={(tab) => {
          setCurrentTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onPrintNotes={() => setIsPrintModalOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 space-y-6">
        {/* VIEW 1: Severe AS Master Blueprint (Question 1.1) */}
        {currentTab === 'severeAS' && (
          <div className="space-y-6">
            {/* Master Summary Top Banner */}
            <div className="bg-slate-900 text-white rounded-2xl p-5 md:p-6 shadow-sm border border-slate-800">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 text-xs font-mono tracking-widest text-emerald-400 font-bold uppercase">
                    <span>3-WEEK CARDIOLOGY SPRINT</span>
                    <span>•</span>
                    <span>QUESTION 1.1</span>
                  </div>
                  <h1 className="text-xl sm:text-2xl font-black tracking-tight mt-1">
                    Master Summary: Management of Severe Aortic Stenosis
                  </h1>
                  <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-3xl">
                    ESC/EACTS 2025 Valvular Heart Disease Guidelines • Cairo University Master's Exam Blueprint
                  </p>
                </div>

                <div className="flex items-center gap-2 self-start md:self-auto">
                  <button
                    type="button"
                    onClick={() => setCurrentTab('simulator')}
                    className="px-3.5 py-2 text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg transition-colors flex items-center gap-1.5 shadow-xs"
                  >
                    <span>Launch Live Triage</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>

            {/* Guideline Color Coding Legend */}
            <GuidelineLegend
              selectedClass={selectedLegendClass}
              onSelectClass={(cls) => setSelectedLegendClass(cls)}
              interactive={true}
            />

            {/* 5-Panel Segmented Navigation Bar */}
            <div className="bg-white border border-slate-200 rounded-xl p-1.5 shadow-xs">
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-1.5">
                {panels.map((p) => {
                  const Icon = p.icon;
                  const isActive = activePanel === p.id;
                  return (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => setActivePanel(p.id)}
                      className={`text-left p-2.5 rounded-lg transition-all ${
                        isActive
                          ? 'bg-slate-900 text-white shadow-xs'
                          : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      <div className="flex items-center gap-1.5">
                        <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-emerald-400' : 'text-slate-500'}`} />
                        <span className="text-xs font-extrabold truncate">{p.title}</span>
                      </div>
                      <div className={`text-[10px] mt-0.5 truncate ${isActive ? 'text-slate-300' : 'text-slate-500'}`}>
                        {p.subtitle}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Active Panel View */}
            <div>
              {activePanel === 1 && <FlowchartPanel />}
              {activePanel === 2 && <ScoringMatrixPanel />}
              {activePanel === 3 && (
                <div className="space-y-6">
                  <ExamBookletPanel />
                  <DseSimulatorCard />
                </div>
              )}
              {activePanel === 4 && <NumberLinePanel />}
              {activePanel === 5 && <ExamTrapsPanel />}
            </div>

            {/* Bottom Panel Navigation Footer */}
            <div className="flex items-center justify-between border-t border-slate-200 pt-4 text-xs font-medium text-slate-500">
              <button
                type="button"
                disabled={activePanel === 1}
                onClick={() => setActivePanel((prev) => Math.max(1, prev - 1))}
                className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-white disabled:opacity-30 disabled:pointer-events-none transition-colors"
              >
                ← Previous Panel
              </button>

              <span className="font-mono text-slate-600">
                Panel {activePanel} of 5
              </span>

              <button
                type="button"
                disabled={activePanel === 5}
                onClick={() => setActivePanel((prev) => Math.min(5, prev + 1))}
                className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-white disabled:opacity-30 disabled:pointer-events-none transition-colors"
              >
                Next Panel →
              </button>
            </div>
          </div>
        )}

        {/* VIEW 2: Aortic Regurgitation (Module 1.6 & 1.7) */}
        {currentTab === 'aorticRegurg' && (
          <div className="space-y-6">
            <GuidelineLegend interactive={false} />
            <OtherModulesView moduleId="ar" />
          </div>
        )}

        {/* VIEW 3: Mitral Regurgitation (Module 1.8 & 1.9) */}
        {currentTab === 'mitralRegurg' && (
          <div className="space-y-6">
            <GuidelineLegend interactive={false} />
            <OtherModulesView moduleId="mr" />
          </div>
        )}

        {/* VIEW 4: Interactive Patient Triage Simulator */}
        {currentTab === 'simulator' && (
          <div className="space-y-6">
            <GuidelineLegend interactive={false} />
            <PatientTriageSimulator />
          </div>
        )}

        {/* VIEW 5: Exam Booklet & DSE Response Card */}
        {currentTab === 'examBooklet' && (
          <div className="space-y-6">
            <GuidelineLegend interactive={false} />
            <ExamBookletPanel />
            <DseSimulatorCard />
          </div>
        )}
      </main>

      {/* Printable Cheat-Sheet Modal */}
      {isPrintModalOpen && <PrintableNotes onClose={() => setIsPrintModalOpen(false)} />}

      {/* Quiet Academic Footer */}
      <footer className="mt-12 border-t border-slate-200 bg-white py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
          <div>
            <span className="font-bold text-slate-800">CardioMaster 2025 Sprint Engine</span>
            <span className="mx-2">·</span>
            <span>Grounded in ESC/EACTS 2025 Valvular Heart Disease Guidelines</span>
          </div>
          <div className="font-mono text-[11px] text-slate-400">
            Cairo University Master's Exam Study System
          </div>
        </div>
      </footer>
    </div>
  );
}
