import React, { useState } from 'react';
import { Activity, ArrowRight, CheckCircle2, XCircle, AlertTriangle, ShieldCheck } from 'lucide-react';

export const DseSimulatorCard: React.FC = () => {
  // Simulator inputs
  const [hasFlowReserve, setHasFlowReserve] = useState<boolean>(true);
  const [svDeltaPercent, setSvDeltaPercent] = useState<number>(28);
  const [peakAva, setPeakAva] = useState<number>(0.85);
  const [peakMeanGrad, setPeakMeanGrad] = useState<number>(44);
  const [patientSex, setPatientSex] = useState<'Male' | 'Female'>('Male');
  const [ctCalciumScore, setCtCalciumScore] = useState<number>(2250);

  // Computed results
  const isSvAdequate = svDeltaPercent >= 20;

  let outcomeType: 'true-severe' | 'pseudo-severe' | 'ct-true-severe' | 'ct-unlikely' | 'ct-intermediate' = 'true-severe';

  if (isSvAdequate) {
    if (peakAva <= 1.0 && peakMeanGrad >= 40) {
      outcomeType = 'true-severe';
    } else {
      outcomeType = 'pseudo-severe';
    }
  } else {
    const highThreshold = patientSex === 'Male' ? 2000 : 1200;
    const lowThreshold = patientSex === 'Male' ? 1600 : 800;

    if (ctCalciumScore >= highThreshold) {
      outcomeType = 'ct-true-severe';
    } else if (ctCalciumScore < lowThreshold) {
      outcomeType = 'ct-unlikely';
    } else {
      outcomeType = 'ct-intermediate';
    }
  }

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4 md:p-6 shadow-xs space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-amber-700 uppercase tracking-wider">
              VISUAL B: DOBUTAMINE ECHO RESPONSE CARD
            </span>
            <span className="px-2 py-0.5 bg-blue-100 text-blue-900 text-[10px] font-bold rounded">
              LFLG PROTOCOL
            </span>
          </div>
          <h3 className="text-base font-extrabold text-slate-900 mt-0.5">
            Low-Dose DSE Protocol & Non-Contrast CT Calcium Arbiter
          </h3>
          <p className="text-xs text-slate-500">
            Mandatory workup for Low-Flow Low-Gradient Severe AS with Reduced LVEF (&lt; 50%)
          </p>
        </div>
        <div className="text-xs font-mono text-slate-600 bg-slate-50 px-2.5 py-1 rounded border border-slate-200 shrink-0">
          Max Dobutamine: 20 µg/kg/min
        </div>
      </div>

      {/* Visual ASCII / SVG Card Layout */}
      <div className="p-4 bg-slate-900 text-slate-100 rounded-xl font-mono text-xs overflow-x-auto leading-relaxed">
        <div className="text-center font-bold text-emerald-400 mb-2">
          LOW-DOSE DOBUTAMINE STRESS ECHO (Max 20 µg/kg/min)
        </div>
        <div className="text-center text-slate-400">│</div>
        <div className="text-center text-amber-300 font-bold">
          Stroke Volume Increase ≥ 20%?
        </div>
        <div className="grid grid-cols-2 gap-4 mt-2">
          {/* YES Flow Reserve */}
          <div className="border border-emerald-500/50 p-2.5 rounded bg-emerald-950/20 text-center">
            <div className="text-emerald-400 font-bold">[ FLOW RESERVE PRESENT ]</div>
            <div className="text-[11px] text-slate-300 mt-1">Check AVA &amp; Gradient at Peak Flow</div>
            <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-emerald-500/30 text-left">
              <div className="p-1 bg-emerald-900/40 rounded">
                <span className="text-emerald-300 font-bold">AVA ≤ 1.0 cm²</span><br />
                <span className="text-emerald-300 font-bold">MG ≥ 40 mmHg</span><br />
                <span className="text-emerald-400 font-extrabold">→ TRUE SEVERE</span><br />
                <span className="text-[10px] text-emerald-200">(Intervene: I B)</span>
              </div>
              <div className="p-1 bg-slate-800 rounded">
                <span className="text-slate-300 font-bold">AVA &gt; 1.0 cm²</span><br />
                <span className="text-slate-300 font-bold">MG &lt; 40 mmHg</span><br />
                <span className="text-amber-400 font-extrabold">→ PSEUDO-SEVERE</span><br />
                <span className="text-[10px] text-slate-400">(Optimize GDMT)</span>
              </div>
            </div>
          </div>

          {/* NO Flow Reserve */}
          <div className="border border-rose-500/50 p-2.5 rounded bg-rose-950/20 text-center">
            <div className="text-rose-400 font-bold">[ NO FLOW RESERVE ]</div>
            <div className="text-[11px] text-slate-300 mt-1">ΔSV &lt; 20% (Exhausted Myocardial Reserve)</div>
            <div className="mt-2 pt-2 border-t border-rose-500/30 text-left text-[11px] space-y-1">
              <div className="text-amber-300 font-bold">Non-contrast CT Calcium Score:</div>
              <div>• Men &gt; 2000 AU / Women &gt; 1200 AU → <span className="text-emerald-400 font-bold">True Severe AS</span> (Intervene: IIa B)</div>
              <div>• Men &lt; 1600 AU / Women &lt; 800 AU → <span className="text-rose-400 font-bold">Unlikely Severe</span> (Surveillance)</div>
            </div>
          </div>
        </div>
      </div>

      {/* Interactive Testing Sandbox */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-4">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-emerald-600" />
          <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
            Interactive DSE Patient Case Tester
          </h4>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Controls */}
          <div className="space-y-3 text-xs">
            <div>
              <label className="font-semibold text-slate-700 flex justify-between">
                <span>Stroke Volume Delta (ΔSV):</span>
                <span className="font-mono font-bold text-emerald-700">+{svDeltaPercent}%</span>
              </label>
              <input
                type="range"
                min="0"
                max="50"
                step="1"
                value={svDeltaPercent}
                onChange={(e) => setSvDeltaPercent(Number(e.target.value))}
                className="w-full mt-1 accent-emerald-600"
              />
              <div className="flex justify-between text-[10px] text-slate-400">
                <span>0% (No reserve)</span>
                <span className="font-bold text-emerald-800">Threshold: 20%</span>
                <span>50%</span>
              </div>
            </div>

            {isSvAdequate ? (
              <div className="grid grid-cols-2 gap-3 pt-2">
                <div>
                  <label className="font-semibold text-slate-700 block">Peak AVA (cm²):</label>
                  <input
                    type="number"
                    step="0.05"
                    min="0.4"
                    max="1.8"
                    value={peakAva}
                    onChange={(e) => setPeakAva(Number(e.target.value))}
                    className="w-full mt-1 p-1.5 text-xs rounded border border-slate-300 font-mono"
                  />
                  <div className="text-[10px] text-slate-500 mt-0.5">Severe cutoff: ≤ 1.0</div>
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block">Peak MG (mmHg):</label>
                  <input
                    type="number"
                    step="1"
                    min="15"
                    max="80"
                    value={peakMeanGrad}
                    onChange={(e) => setPeakMeanGrad(Number(e.target.value))}
                    className="w-full mt-1 p-1.5 text-xs rounded border border-slate-300 font-mono"
                  />
                  <div className="text-[10px] text-slate-500 mt-0.5">Severe cutoff: ≥ 40</div>
                </div>
              </div>
            ) : (
              <div className="pt-2 space-y-2 border-t border-slate-200">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-slate-700">Patient Biological Sex:</span>
                  <div className="flex rounded border border-slate-300 overflow-hidden text-xs">
                    <button
                      type="button"
                      onClick={() => setPatientSex('Male')}
                      className={`px-3 py-1 font-semibold ${patientSex === 'Male' ? 'bg-slate-900 text-white' : 'bg-white text-slate-700'}`}
                    >
                      Male (&gt;2000)
                    </button>
                    <button
                      type="button"
                      onClick={() => setPatientSex('Female')}
                      className={`px-3 py-1 font-semibold ${patientSex === 'Female' ? 'bg-slate-900 text-white' : 'bg-white text-slate-700'}`}
                    >
                      Female (&gt;1200)
                    </button>
                  </div>
                </div>
                <div>
                  <label className="font-semibold text-slate-700 flex justify-between">
                    <span>CT Calcium Score (Agatston AU):</span>
                    <span className="font-mono font-bold text-blue-700">{ctCalciumScore} AU</span>
                  </label>
                  <input
                    type="range"
                    min="400"
                    max="3500"
                    step="50"
                    value={ctCalciumScore}
                    onChange={(e) => setCtCalciumScore(Number(e.target.value))}
                    className="w-full mt-1 accent-blue-600"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Real-time Computed Decision Box */}
          <div className="p-3.5 bg-white border border-slate-200 rounded-lg flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                Clinical Diagnosis & ESC 2025 Action
              </span>

              {outcomeType === 'true-severe' && (
                <div className="space-y-1.5">
                  <div className="flex items-center gap-1.5 text-emerald-800 font-extrabold text-sm">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                    TRUE SEVERE AORTIC STENOSIS
                  </div>
                  <div className="text-xs text-slate-700">
                    Adequate contractile flow reserve demonstrated (+{svDeltaPercent}% SV). Valve area remains fixed at {peakAva} cm² with gradient increasing to {peakMeanGrad} mmHg.
                  </div>
                  <div className="text-xs font-bold text-emerald-900 bg-emerald-50 p-2 rounded border border-emerald-200">
                    Recommendation: Aortic Valve Intervention (Class I, Level of Evidence B)
                  </div>
                </div>
              )}

              {outcomeType === 'pseudo-severe' && (
                <div className="space-y-1.5">
                  <div className="flex items-center gap-1.5 text-amber-800 font-extrabold text-sm">
                    <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
                    PSEUDO-SEVERE AORTIC STENOSIS
                  </div>
                  <div className="text-xs text-slate-700">
                    Flow reserve recruited (+{svDeltaPercent}% SV) allowed the stenotic valve to open wider (AVA {peakAva} cm² &gt; 1.0 cm²). True anatomical obstruction is mild-to-moderate.
                  </div>
                  <div className="text-xs font-bold text-slate-800 bg-amber-50 p-2 rounded border border-amber-200">
                    Recommendation: Do NOT intervene. Optimize Heart Failure GDMT (ARNI, BB, MRA, SGLT2i). Class III for TAVI/SAVR.
                  </div>
                </div>
              )}

              {outcomeType === 'ct-true-severe' && (
                <div className="space-y-1.5">
                  <div className="flex items-center gap-1.5 text-emerald-800 font-extrabold text-sm">
                    <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
                    TRUE SEVERE AS (CT CALCIUM PROVEN)
                  </div>
                  <div className="text-xs text-slate-700">
                    Contractile reserve exhausted (ΔSV &lt; 20%), but CT Agatston score ({ctCalciumScore} AU) exceeds severe threshold for {patientSex.toLowerCase()}s ({patientSex === 'Male' ? '> 2000' : '> 1200'} AU).
                  </div>
                  <div className="text-xs font-bold text-emerald-900 bg-emerald-50 p-2 rounded border border-emerald-200">
                    Recommendation: Valve Intervention Should Be Considered (Class IIa, Level of Evidence B; TAVI favored due to high surgical mortality with no reserve).
                  </div>
                </div>
              )}

              {outcomeType === 'ct-unlikely' && (
                <div className="space-y-1.5">
                  <div className="flex items-center gap-1.5 text-rose-800 font-extrabold text-sm">
                    <XCircle className="w-5 h-5 text-rose-600 shrink-0" />
                    SEVERE AS UNLIKELY
                  </div>
                  <div className="text-xs text-slate-700">
                    Calcium load is low ({ctCalciumScore} AU vs cutoff {patientSex === 'Male' ? '< 1600' : '< 800'}). Stenosis is moderate or pseudo-severe.
                  </div>
                  <div className="text-xs font-bold text-rose-900 bg-rose-50 p-2 rounded border border-rose-200">
                    Recommendation: Conservative surveillance. Re-evaluate cardiomyopathy and medical therapy.
                  </div>
                </div>
              )}

              {outcomeType === 'ct-intermediate' && (
                <div className="space-y-1.5">
                  <div className="flex items-center gap-1.5 text-amber-800 font-extrabold text-sm">
                    <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
                    INTERMEDIATE / GREY ZONE CALCIUM
                  </div>
                  <div className="text-xs text-slate-700">
                    Calcium score ({ctCalciumScore} AU) is in the indeterminate range ({patientSex === 'Male' ? '1600-2000' : '800-1200'}).
                  </div>
                  <div className="text-xs font-bold text-amber-900 bg-amber-50 p-2 rounded border border-amber-200">
                    Recommendation: Heart Valve Team multimodal synthesis (CMR, transesophageal 3D planimetry, invasive catheterization).
                  </div>
                </div>
              )}
            </div>

            <div className="mt-3 text-[10px] text-slate-500 border-t border-slate-100 pt-2 italic">
              Key exam point: Lack of contractile reserve does not preclude TAVI benefit!
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
