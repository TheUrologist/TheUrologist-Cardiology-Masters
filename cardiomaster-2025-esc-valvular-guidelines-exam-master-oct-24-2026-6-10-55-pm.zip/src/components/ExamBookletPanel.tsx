import React, { useState, useEffect } from 'react';
import { EXAM_RUBRIC_15_MARKS } from '../data/severeASData';
import { FileText, Play, Pause, RotateCcw, CheckSquare, Square, Copy, Check, Printer } from 'lucide-react';

export const ExamBookletPanel: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'linedPaper' | 'modelAnswer' | 'rubricChecklist'>('linedPaper');
  const [activePage, setActivePage] = useState<1 | 2 | 3>(1);

  // Timer state for 15-minute exam sprint
  const [timeLeft, setTimeLeft] = useState<number>(15 * 60);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);

  // Checked rubric items
  const [checkedRubric, setCheckedRubric] = useState<Record<string, boolean>>({
    'rubric-1': true,
    'rubric-2': true,
  });

  const [copied, setCopied] = useState<boolean>(false);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isTimerRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, timeLeft]);

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const toggleRubric = (id: string) => {
    setCheckedRubric((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const totalCalculatedScore = EXAM_RUBRIC_15_MARKS.reduce((acc, curr) => {
    return acc + (checkedRubric[curr.id] ? curr.marks : 0);
  }, 0);

  const fullModelAnswerText = `MANAGEMENT OF SEVERE AORTIC STENOSIS (ESC/EACTS 2025 GUIDELINES)
Cairo University Master's Exam Question 1.1 Model Answer

1. DIAGNOSTIC TRIAD & CONFIRMATION
• Criteria: AVA ≤ 1.0 cm² (indexed AVAi ≤ 0.60 cm²/m²), Mean Gradient ≥ 40 mmHg, Vmax ≥ 4.0 m/s.
• Flow Phenotyping:
  - Concordant High-Gradient: Mean Grad ≥ 40 mmHg (Severe AS confirmed).
  - Low-Flow Low-Gradient (Reduced EF < 50%, SVi ≤ 35 mL/m²): Perform Low-dose Dobutamine Stress Echo (DSE up to 20 µg/kg/min). Flow reserve defined as ΔSV ≥ 20%. If AVA remains ≤ 1.0 cm² with Mean Grad ≥ 40 mmHg → True Severe AS. If AVA > 1.0 cm² → Pseudo-severe AS (optimize GDMT). If no flow reserve → CT Calcium Score.
  - Low-Flow Low-Gradient (Preserved EF ≥ 50%, SVi ≤ 35 mL/m²): Non-contrast CT Calcium score: Men > 2000 AU, Women > 1200 AU = Severe AS.
  - Normal-Flow Low-Gradient (SVi > 35 mL/m²): Usually moderate AS; recheck LVOT diameter and BP; active surveillance.

2. SYMPTOMATIC VS ASYMPTOMATIC TRIAGE
• Symptomatic Severe AS:
  - Life expectancy > 1 year & meaningful QoL: Intervention recommended (Class I, LoE B).
  - Futility / severe comorbidity: Conservative / palliative care (Class III).
• Asymptomatic Severe AS:
  - Mandated Exercise Testing: Unmasks hidden symptoms (exertional dyspnea/angina → Class I, LoE B; fall in SBP > 20 mmHg → Class IIa, LoE C).
  - If truly asymptomatic with normal exercise test, scan for triggers:
    * Resting LVEF < 50% without other cause → Class I, LoE B.
    * Concomitant CABG, other valve, or ascending aorta surgery → Class I, LoE C.
    * High-gradient + LVEF ≥ 50% + normal exercise test + low procedural risk → Class IIa, LoE A (NEW 2025: RECOVERY & AVATAR trials).
    * V-C-B-L-E Triggers → Class IIa, LoE B:
      - V: Very severe gradient (Mean Grad ≥ 60 mmHg or Vmax > 5.0 m/s)
      - C: Calcification severe on CT + rapid progression (ΔVmax ≥ 0.3 m/s/yr)
      - B: BNP / NT-proBNP > 3x normal limit confirmed on repeat
      - L: LVEF decline (resting LVEF 50% to 54%)
      - E: Exercise test abnormal (sustained SBP drop > 20 mmHg)
  - If no triggers met: Active Valve Clinic Surveillance every 6 months.

3. MODE SELECTION (HEART TEAM: SAVR VS TAVI)
• Age ≥ 70 years OR High Surgical Risk (EuroSCORE II / STS ≥ 4%): TAVI recommended (Class I, LoE A; transfemoral route).
• Age < 70 years AND Low Surgical Risk (EuroSCORE II / STS < 4%): SAVR recommended (Class I, LoE B; mechanical valve if age < 60 without anticoagulation contraindication).
• Bicuspid Aortic Valve + High Risk: TAVI may be considered (Class IIb, LoE B) after CT anatomical sizing.

4. MEDICAL THERAPY & SPECIAL CAUTIONS
• Statins DO NOT halt calcific progression (ASTRONOMER & SALTIRE trials; Class III).
• Control hypertension cautiously with low-dose agents; avoid sudden vasodilator preload/afterload drops.
• Serial 6-month clinical and echocardiographic re-evaluation.`;

  const copyAnswer = () => {
    navigator.clipboard.writeText(fullModelAnswerText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Exam Simulation Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-amber-700 uppercase tracking-wider">
              VISUAL A: 30-SECOND EXAM BOOKLET BLUEPRINT
            </span>
            <span className="px-2 py-0.5 bg-amber-100 text-amber-900 text-[10px] font-extrabold rounded">
              15 MARKS
            </span>
          </div>
          <h3 className="text-base font-extrabold text-slate-900 mt-0.5">
            How to Layout the 15-Mark Written Answer on Lined Paper
          </h3>
          <p className="text-xs text-slate-500">
            Cairo University Master's Question 1.1: Management of Asymptomatic Severe AS
          </p>
        </div>

        {/* 15-Minute Countdown Timer Widget */}
        <div className="flex items-center gap-3 bg-slate-50 p-2.5 rounded-lg border border-slate-200 shrink-0">
          <div className="text-right">
            <div className="text-[10px] font-bold text-slate-500 uppercase">Exam Sprint Timer</div>
            <div
              className={`font-mono text-lg font-extrabold tabular-nums ${
                timeLeft < 180 ? 'text-rose-600 animate-pulse' : 'text-slate-900'
              }`}
            >
              {formatTimer(timeLeft)}
            </div>
          </div>
          <div className="flex items-center gap-1 border-l border-slate-200 pl-3">
            <button
              type="button"
              onClick={() => setIsTimerRunning(!isTimerRunning)}
              className="p-1.5 rounded-md bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 transition-colors"
              title={isTimerRunning ? 'Pause' : 'Start'}
            >
              {isTimerRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </button>
            <button
              type="button"
              onClick={() => {
                setIsTimerRunning(false);
                setTimeLeft(15 * 60);
              }}
              className="p-1.5 rounded-md bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 transition-colors"
              title="Reset Timer"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Mode Switcher Tabs */}
      <div className="flex items-center justify-between gap-2 border-b border-slate-200 pb-2">
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg text-xs font-semibold">
          <button
            type="button"
            onClick={() => setActiveTab('linedPaper')}
            className={`px-3 py-1.5 rounded-md transition-all ${
              activeTab === 'linedPaper'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Lined Paper Visual (Exam Simulation)
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('rubricChecklist')}
            className={`px-3 py-1.5 rounded-md transition-all flex items-center gap-1 ${
              activeTab === 'rubricChecklist'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            15-Mark Rubric Scorecard ({totalCalculatedScore}/15)
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('modelAnswer')}
            className={`px-3 py-1.5 rounded-md transition-all ${
              activeTab === 'modelAnswer'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Full Model Answer Text
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={copyAnswer}
            className="flex items-center gap-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 px-3 py-1.5 rounded-lg shadow-xs transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy Model Answer'}</span>
          </button>
        </div>
      </div>

      {/* TAB 1: Lined Exam Booklet Visual */}
      {activeTab === 'linedPaper' && (
        <div className="space-y-4">
          {/* Page Selector Tabs */}
          <div className="flex items-center justify-center gap-2">
            {[1, 2, 3].map((page) => (
              <button
                key={page}
                type="button"
                onClick={() => setActivePage(page as 1 | 2 | 3)}
                className={`px-4 py-1.5 text-xs font-bold rounded-full transition-colors ${
                  activePage === page
                    ? 'bg-slate-900 text-white'
                    : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                Page {page} {page === 1 ? '(Diagnosis & Algorithm)' : page === 2 ? '(Class/LoE & Mode)' : '(Surveillance & Traps)'}
              </button>
            ))}
          </div>

          {/* Lined Paper Canvas */}
          <div className="relative mx-auto max-w-4xl bg-white border-2 border-slate-300 rounded-xl shadow-lg overflow-hidden lined-paper p-6 md:p-10 font-mono text-slate-900">
            {/* Top Red Margin line representation is handled in CSS */}
            <div className="text-right text-xs text-slate-400 font-sans mb-4">
              Cairo University Faculty of Medicine • Cardiology Master's Exam • Page {activePage} of 3
            </div>

            {activePage === 1 && (
              <div className="space-y-6">
                <div>
                  <h4 className="text-sm font-bold text-blue-900 bg-blue-50/80 px-2 py-0.5 rounded inline-block">
                    [PAGE 1 TOP] 1. DIAGNOSTIC TRIAD & CONFIRMATION
                  </h4>
                  <p className="text-xs mt-1 text-slate-700">
                    Candidate must draw a concise 3-box diagnostic confirmation header:
                  </p>
                  <div className="mt-2 grid grid-cols-3 gap-2 text-center text-xs border border-blue-300 bg-blue-50/60 p-2 rounded">
                    <div>
                      <div className="font-bold text-blue-900">AVA ≤ 1.0 cm²</div>
                      <div className="text-[10px] text-slate-600">Indexed ≤ 0.6 cm²/m²</div>
                    </div>
                    <div className="border-x border-blue-200">
                      <div className="font-bold text-blue-900">Mean Grad ≥ 40 mmHg</div>
                      <div className="text-[10px] text-slate-600">Continuous Wave Doppler</div>
                    </div>
                    <div>
                      <div className="font-bold text-blue-900">Vmax ≥ 4.0 m/s</div>
                      <div className="text-[10px] text-slate-600">Peak Jet Velocity</div>
                    </div>
                  </div>
                  <div className="text-[11px] text-slate-600 mt-2 italic">
                    Annotation: "Always exclude pseudo-severe AS & unmask symptoms via exercise testing prior to asymptomatic designation."
                  </div>
                </div>

                <div className="border-t border-slate-300 pt-4">
                  <h4 className="text-sm font-bold text-emerald-900 bg-emerald-50/80 px-2 py-0.5 rounded inline-block">
                    [PAGE 1 MID] 2. DECISION ALGORITHM SKETCH
                  </h4>
                  <p className="text-xs mt-1 text-slate-700">
                    Candidate sketches the 30-second box diagram:
                  </p>
                  <div className="mt-2 p-3 bg-slate-50 border border-slate-300 rounded text-xs space-y-2 leading-relaxed">
                    <div className="font-bold text-slate-800">
                      Asymptomatic Severe AS (Confirmed)
                    </div>
                    <div className="pl-4 border-l-2 border-emerald-500 space-y-1">
                      <div>├─ 1. Resting LVEF &lt; 50% without other cause ────► <span className="font-bold text-emerald-700">[ INTERVENE: Class I, LoE B ]</span></div>
                      <div>├─ 2. Exercise Stress Testing:</div>
                      <div className="pl-4">│  ├─ Develops exertional angina/dyspnea ────► <span className="font-bold text-emerald-700">[ INTERVENE: Class I, LoE B ]</span></div>
                      <div className="pl-4">│  └─ Sustained SBP drop &gt; 20 mmHg ───────────► <span className="font-bold text-amber-700">[ INTERVENE: Class IIa, LoE C ]</span></div>
                      <div>├─ 3. Low procedural risk + Normal ET + Preserved EF ─► <span className="font-bold text-amber-700">[ INTERVENE: Class IIa, LoE A ★ NEW 2025 ]</span></div>
                      <div>├─ 4. V-C-B-L-E Triggers Met ──────────────────────► <span className="font-bold text-amber-700">[ INTERVENE: Class IIa, LoE B ]</span></div>
                      <div>└─ 5. No Triggers Met ──────────────────────────────► <span className="font-bold text-blue-700">[ Active Surveillance q6m ]</span></div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activePage === 2 && (
              <div className="space-y-6">
                <div>
                  <h4 className="text-sm font-bold text-amber-900 bg-amber-50/80 px-2 py-0.5 rounded inline-block">
                    [PAGE 2 TOP] 3. SUMMARY TABLE: CLASS & LEVEL OF EVIDENCE
                  </h4>
                  <p className="text-xs mt-1 text-slate-700">
                    Tabular layout demonstrating mastery of the 2025 guidelines:
                  </p>
                  <div className="mt-2 overflow-x-auto">
                    <table className="w-full text-xs border border-slate-300 divide-y divide-slate-200">
                      <thead className="bg-slate-100">
                        <tr>
                          <th className="p-1.5 text-left font-bold">Trigger Criterion</th>
                          <th className="p-1.5 text-center font-bold">Class</th>
                          <th className="p-1.5 text-center font-bold">LoE</th>
                          <th className="p-1.5 text-left font-bold">Key Landmark Trial / Rationale</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        <tr>
                          <td className="p-1.5">LVEF &lt; 50% without other cause</td>
                          <td className="p-1.5 text-center font-bold text-emerald-700">Class I</td>
                          <td className="p-1.5 text-center font-bold">B</td>
                          <td className="p-1.5 text-slate-600">Prevents irreversible LV fibrosis</td>
                        </tr>
                        <tr>
                          <td className="p-1.5">Concomitant CABG / Aortic surgery</td>
                          <td className="p-1.5 text-center font-bold text-emerald-700">Class I</td>
                          <td className="p-1.5 text-center font-bold">C</td>
                          <td className="p-1.5 text-slate-600">Avoid re-operation within 5 years</td>
                        </tr>
                        <tr className="bg-amber-50/40">
                          <td className="p-1.5 font-bold">High-gradient + Normal ET + Low Risk</td>
                          <td className="p-1.5 text-center font-bold text-amber-700">Class IIa</td>
                          <td className="p-1.5 text-center font-bold">A</td>
                          <td className="p-1.5 font-semibold text-emerald-800">RECOVERY & AVATAR trials (NEW 2025)</td>
                        </tr>
                        <tr>
                          <td className="p-1.5">Very severe gradient (MG ≥ 60 or Vmax &gt; 5.0)</td>
                          <td className="p-1.5 text-center font-bold text-amber-700">Class IIa</td>
                          <td className="p-1.5 text-center font-bold">B</td>
                          <td className="p-1.5 text-slate-600">High sudden cardiac death risk</td>
                        </tr>
                        <tr>
                          <td className="p-1.5">Markedly elevated BNP (&gt; 3x normal limit)</td>
                          <td className="p-1.5 text-center font-bold text-amber-700">Class IIa</td>
                          <td className="p-1.5 text-center font-bold">B</td>
                          <td className="p-1.5 text-slate-600">Occult LV end-diastolic wall stress</td>
                        </tr>
                        <tr>
                          <td className="p-1.5">Resting LVEF 50% to 54% (subclinical decline)</td>
                          <td className="p-1.5 text-center font-bold text-amber-700">Class IIa</td>
                          <td className="p-1.5 text-center font-bold">B</td>
                          <td className="p-1.5 text-slate-600">Early systolic decompensation</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>

                <div className="border-t border-slate-300 pt-4">
                  <h4 className="text-sm font-bold text-purple-900 bg-purple-50/80 px-2 py-0.5 rounded inline-block">
                    [PAGE 2 MID] 4. MODE SELECTION (THE AGE 70 LINE)
                  </h4>
                  <p className="text-xs mt-1 text-slate-700">
                    Hand-drawn age dichotomy diagram:
                  </p>
                  <div className="mt-2 p-3 bg-purple-50/50 border border-purple-200 rounded text-xs">
                    <div className="text-center font-bold text-purple-950 mb-2">
                      ─── THE 2025 AGE 70 DICHOTOMY LINE ───
                    </div>
                    <div className="flex flex-col sm:flex-row items-center justify-around gap-4 text-center">
                      <div className="p-2 bg-white rounded border border-purple-200 flex-1">
                        <div className="font-bold text-blue-900">Age &lt; 70 Years AND Low Risk</div>
                        <div className="text-[11px] text-slate-500">STS / EuroSCORE II &lt; 4%</div>
                        <div className="mt-1 font-extrabold text-emerald-700">SAVR (Class I, LoE B)</div>
                        <div className="text-[10px] text-slate-600">Mechanical if &lt; 60 & no warfarin CI</div>
                      </div>
                      <div className="text-purple-700 font-extrabold text-lg">VS</div>
                      <div className="p-2 bg-white rounded border border-purple-200 flex-1">
                        <div className="font-bold text-purple-900">Age ≥ 70 Years OR High Risk</div>
                        <div className="text-[11px] text-slate-500">STS / EuroSCORE II ≥ 4%</div>
                        <div className="mt-1 font-extrabold text-emerald-700">TAVI (Class I, LoE A)</div>
                        <div className="text-[10px] text-slate-600">Transfemoral route standard</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activePage === 3 && (
              <div className="space-y-6">
                <div>
                  <h4 className="text-sm font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded inline-block">
                    [PAGE 3] 5. SURVEILLANCE & SPECIAL CAUTIONS (HIGH-YIELD MARKS)
                  </h4>
                  <div className="mt-3 space-y-3 text-xs leading-relaxed">
                    <div className="bg-slate-50 p-2.5 rounded border border-slate-200">
                      <span className="font-bold text-slate-900">1. Active Valve Clinic Surveillance Protocol:</span>
                      <ul className="list-disc pl-5 mt-1 space-y-0.5 text-slate-700">
                        <li>Evaluate every 6 months in a dedicated Heart Valve Clinic.</li>
                        <li>Detailed symptom questioning + resting TTE at each visit.</li>
                        <li>Patient education on warning symptoms (angina, lightheadedness, exertional breathlessness).</li>
                      </ul>
                    </div>

                    <div className="bg-rose-50 p-2.5 rounded border border-rose-200 text-rose-950">
                      <span className="font-bold">2. Medical Therapy Reality (EXAM TRAP):</span>
                      <div className="mt-1 text-slate-700">
                        Statins <span className="font-bold text-rose-800">DO NOT</span> slow hemodynamic or calcific progression of aortic stenosis (Class III / futile for this indication; proven by <span className="font-semibold">SALTIRE</span> and <span className="font-semibold">ASTRONOMER</span> trials).
                      </div>
                    </div>

                    <div className="bg-amber-50 p-2.5 rounded border border-amber-200 text-amber-950">
                      <span className="font-bold">3. Hypertension & Afterload Management:</span>
                      <div className="mt-1 text-slate-700">
                        Treat hypertension carefully to avoid "double afterload" on the LV. Start with low-dose ACEi/ARB or beta-blockers. Avoid rapid vasodilator titration which risks acute syncope or coronary hypoperfusion.
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: Rubric Checklist */}
      {activeTab === 'rubricChecklist' && (
        <div className="bg-white border border-slate-200 rounded-xl p-4 md:p-6 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
            <div>
              <h4 className="text-base font-extrabold text-slate-900">
                15-Mark Cairo Master's Exam Marking Scheme Checklist
              </h4>
              <p className="text-xs text-slate-500">
                Check off each element you included in your answer to calculate your predicted score:
              </p>
            </div>
            <div className="text-right">
              <span className="text-2xl font-black text-emerald-600 font-mono">
                {totalCalculatedScore}
              </span>
              <span className="text-sm font-bold text-slate-500"> / 15 Marks</span>
            </div>
          </div>

          <div className="space-y-3">
            {EXAM_RUBRIC_15_MARKS.map((item) => {
              const isChecked = !!checkedRubric[item.id];
              return (
                <div
                  key={item.id}
                  onClick={() => toggleRubric(item.id)}
                  className={`p-3 rounded-lg border transition-all cursor-pointer flex items-start gap-3 ${
                    isChecked
                      ? 'bg-emerald-50/70 border-emerald-300 text-slate-900'
                      : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <button type="button" className="mt-0.5 shrink-0 text-emerald-600">
                    {isChecked ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4 text-slate-400" />}
                  </button>
                  <div className="flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-bold text-xs uppercase tracking-wide text-slate-800">
                        {item.section}
                      </span>
                      <span className="text-xs font-mono font-bold bg-white px-2 py-0.5 rounded border border-slate-200">
                        {item.marks} Mark(s)
                      </span>
                    </div>
                    <p className="text-xs text-slate-700 mt-1">{item.criterion}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: Model Answer Text */}
      {activeTab === 'modelAnswer' && (
        <div className="bg-white border border-slate-200 rounded-xl p-4 md:p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h4 className="text-base font-extrabold text-slate-900">
              Complete Model Answer Transcript (Ready to Memorize)
            </h4>
            <span className="text-xs text-slate-500 font-mono">
              Aligned with ESC 2025 Guidelines
            </span>
          </div>
          <pre className="p-4 bg-slate-900 text-slate-100 rounded-lg text-xs font-mono leading-relaxed overflow-x-auto whitespace-pre-wrap">
            {fullModelAnswerText}
          </pre>
        </div>
      )}
    </div>
  );
};
