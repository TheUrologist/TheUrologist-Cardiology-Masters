import React, { useState } from 'react';
import { HIGH_YIELD_TRAPS } from '../data/severeASData';
import { AlertOctagon, CheckCircle2, HelpCircle, ArrowRight, RotateCcw } from 'lucide-react';

interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  trapTag: string;
}

const TRAP_QUIZ: QuizQuestion[] = [
  {
    id: 1,
    question: 'According to the ESC/EACTS 2025 Guidelines, what is the standard age cutoff where TAVI is recommended as Class I (LoE A) over SAVR?',
    options: ['Age ≥ 65 years', 'Age ≥ 70 years', 'Age ≥ 75 years', 'Age ≥ 80 years'],
    correctIndex: 1,
    explanation: 'The ESC/EACTS 2025 update lowered the standard age threshold for TAVI recommendation from 75 down to ≥ 70 years (Class I, LoE A). Quoting 75 years was the 2021 guideline and is now penalized in current exams.',
    trapTag: 'Age Dichotomy 2025',
  },
  {
    id: 2,
    question: 'A 64-year-old asymptomatic man has high-gradient severe AS (AVA 0.8 cm², Mean Grad 48 mmHg, LVEF 60%), a completely normal exercise test, and STS score of 1.1%. What is the ESC 2025 recommendation?',
    options: [
      'Watchful waiting only until symptoms or LVEF < 50% occur (Class I)',
      'Early elective intervention as an alternative to surveillance (Class IIa, LoE A)',
      'Immediate statin therapy to arrest valve calcification (Class I)',
      'Dobutamine stress echo to test for occult ischemia (Class IIa)'
    ],
    correctIndex: 1,
    explanation: 'ESC 2025 introduced Class IIa, LoE A for early intervention in asymptomatic high-gradient severe AS with preserved EF and normal exercise tolerance if procedural risk is low, supported by the landmark RECOVERY and AVATAR randomized clinical trials.',
    trapTag: 'Asymptomatic Early Surgery',
  },
  {
    id: 3,
    question: 'Which statement regarding medical therapy in calcific aortic stenosis is correct in guideline-based practice?',
    options: [
      'High-intensity statins (Atorvastatin 80mg) significantly reduce aortic valve calcification and delay SAVR.',
      'Statins have failed to slow hemodynamic or calcific progression in randomized trials (SALTIRE, ASTRONOMER).',
      'Aggressive rapid titration of nitroprusside is first-line to drop transvalvular gradient.',
      'ACE inhibitors are absolutely contraindicated in all stages of severe aortic stenosis.'
    ],
    correctIndex: 1,
    explanation: 'Both the SALTIRE and ASTRONOMER randomized trials proved that statins do not slow valvular calcium accumulation or hemodynamic progression. Hypertension must be treated cautiously, avoiding precipitous drops in preload/afterload.',
    trapTag: 'Statins Myth',
  },
  {
    id: 4,
    question: 'In low-flow low-gradient severe AS with reduced LVEF (LFLG-redEF), dobutamine stress echocardiography shows a 12% rise in stroke volume. What is the mandatory next step?',
    options: [
      'Discharge patient with diagnosis of pseudo-severe AS.',
      'Non-contrast cardiac CT calcium scoring to assess valve Agatston score.',
      'Repeat DSE with high-dose dobutamine up to 40 µg/kg/min.',
      'Emergency coronary angiogram and intra-aortic balloon pump.'
    ],
    correctIndex: 1,
    explanation: 'A stroke volume increase < 20% indicates absence of contractile flow reserve. This does NOT rule out severe AS; rather, contractile reserve is exhausted. The next mandatory step is Non-contrast Cardiac CT Calcium score (> 2000 AU in men, > 1200 AU in women) to arbitrate true severe stenosis.',
    trapTag: 'DSE Exhaustion & CT Calcium',
  },
  {
    id: 5,
    question: 'A 70-year-old patient presents with blood pressure 185/105 mmHg, AVA 0.8 cm², and Mean Gradient 32 mmHg with SVi 32 mL/m². What is the appropriate initial action?',
    options: [
      'Schedule urgent TAVI for discordant low-gradient severe AS.',
      'Control systemic hypertension to SBP < 140 mmHg and repeat echocardiography.',
      'Classify as irreversible pseudo-severe AS.',
      'Refer for immediate balloon aortic valvuloplasty.'
    ],
    correctIndex: 1,
    explanation: 'Severe systemic hypertension creates high peripheral vascular resistance (valvular-vascular afterload mismatch), which artificially reduces forward stroke volume and blunts the transvalvular mean gradient. Echo must be repeated once blood pressure is normalized.',
    trapTag: 'Systemic HTN Afterload Trap',
  },
];

export const ExamTrapsPanel: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'cards' | 'quiz'>('cards');
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [showResults, setShowResults] = useState<boolean>(false);

  const handleSelectOption = (questionId: number, optionIdx: number) => {
    if (showResults) return;
    setSelectedAnswers((prev) => ({
      ...prev,
      [questionId]: optionIdx,
    }));
  };

  const calculateQuizScore = () => {
    return TRAP_QUIZ.reduce((score, q) => {
      return score + (selectedAnswers[q.id] === q.correctIndex ? 1 : 0);
    }, 0);
  };

  const resetQuiz = () => {
    setSelectedAnswers({});
    setShowResults(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 md:p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-rose-700 uppercase tracking-wider">
              PANEL 5: HIGH-YIELD EXAM TRAPS
            </span>
            <span className="px-2 py-0.5 bg-rose-100 text-rose-900 text-[10px] font-extrabold rounded">
              FATAL EXAM ERRORS
            </span>
          </div>
          <h3 className="text-base font-extrabold text-slate-900 mt-0.5">
            The 5 Classic Pitfalls Tested by Cairo University & European Boards
          </h3>
          <p className="text-xs text-slate-500">
            Differentiating outdated clinical practice from the ESC 2025 valvular guideline paradigm
          </p>
        </div>

        {/* Tab switch */}
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg text-xs font-semibold shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('cards')}
            className={`px-3 py-1.5 rounded-md transition-all ${
              activeTab === 'cards'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Trap Compendium
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('quiz')}
            className={`px-3 py-1.5 rounded-md transition-all ${
              activeTab === 'quiz'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Trap Flashcard Quiz (5 Qs)
          </button>
        </div>
      </div>

      {/* TAB 1: Trap Compendium Cards */}
      {activeTab === 'cards' && (
        <div className="space-y-4">
          {HIGH_YIELD_TRAPS.map((trap, idx) => (
            <div
              key={trap.id}
              className="bg-white border border-slate-200 rounded-xl p-4 md:p-5 shadow-xs space-y-3"
            >
              <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-rose-100 text-rose-800 flex items-center justify-center font-bold text-xs">
                    {idx + 1}
                  </span>
                  <h4 className="font-extrabold text-slate-900 text-sm">{trap.title}</h4>
                </div>
                <span className="text-[10px] font-mono font-bold bg-slate-100 text-slate-600 px-2 py-0.5 rounded">
                  High Exam Frequency
                </span>
              </div>

              {/* Grid Comparison */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                {/* Old Practice */}
                <div className="p-3 bg-rose-50/50 border border-rose-200 rounded-lg space-y-1">
                  <div className="text-[10px] font-bold text-rose-800 uppercase tracking-wider">
                    ❌ Outdated Practice / Exam Trap
                  </div>
                  <p className="text-slate-700 leading-relaxed">{trap.oldPractice}</p>
                </div>

                {/* ESC 2025 Guideline */}
                <div className="p-3 bg-emerald-50/50 border border-emerald-200 rounded-lg space-y-1">
                  <div className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider">
                    ✓ ESC/EACTS 2025 Guideline Benchmark
                  </div>
                  <p className="text-slate-700 leading-relaxed">{trap.new2025Guideline}</p>
                </div>
              </div>

              {/* Bottom Significance & Trial Citations */}
              <div className="pt-2 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-slate-600">
                <div>
                  <span className="font-bold text-slate-800">Exam Impact: </span>
                  {trap.examSignificance}
                </div>
                <div className="font-mono text-[11px] text-blue-800 bg-blue-50 px-2 py-0.5 rounded shrink-0">
                  {trap.evidenceTrials}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* TAB 2: Interactive Quiz */}
      {activeTab === 'quiz' && (
        <div className="bg-white border border-slate-200 rounded-xl p-4 md:p-6 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
            <div>
              <h4 className="text-base font-extrabold text-slate-900">
                CardioMaster Board Exam Trap Quiz
              </h4>
              <p className="text-xs text-slate-500">
                5 targeted multiple-choice questions reflecting the latest ESC 2025 scoring keys
              </p>
            </div>
            {showResults && (
              <div className="flex items-center gap-3">
                <span className="text-xs font-bold text-slate-700">
                  Your Score: <span className="text-emerald-700 font-mono text-base">{calculateQuizScore()}</span> / 5
                </span>
                <button
                  type="button"
                  onClick={resetQuiz}
                  className="flex items-center gap-1 text-xs px-2.5 py-1 bg-slate-100 hover:bg-slate-200 rounded text-slate-700 transition-colors"
                >
                  <RotateCcw className="w-3.5 h-3.5" /> Retake
                </button>
              </div>
            )}
          </div>

          <div className="space-y-6">
            {TRAP_QUIZ.map((q, idx) => {
              const selectedOpt = selectedAnswers[q.id];
              const isAnswered = selectedOpt !== undefined;

              return (
                <div key={q.id} className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <span className="text-xs font-bold text-slate-900 leading-snug">
                      Question {idx + 1}: {q.question}
                    </span>
                    <span className="text-[10px] font-mono text-slate-500 bg-white px-2 py-0.5 rounded border border-slate-200 shrink-0">
                      {q.trapTag}
                    </span>
                  </div>

                  {/* Options */}
                  <div className="space-y-1.5">
                    {q.options.map((opt, optIdx) => {
                      const isChosen = selectedOpt === optIdx;
                      let optStyle = 'bg-white border-slate-200 hover:border-slate-300 text-slate-800';

                      if (showResults) {
                        if (optIdx === q.correctIndex) {
                          optStyle = 'bg-emerald-100 border-emerald-500 text-emerald-950 font-bold';
                        } else if (isChosen && optIdx !== q.correctIndex) {
                          optStyle = 'bg-rose-100 border-rose-400 text-rose-950';
                        } else {
                          optStyle = 'bg-white border-slate-200 opacity-60';
                        }
                      } else if (isChosen) {
                        optStyle = 'bg-slate-900 border-slate-900 text-white font-semibold';
                      }

                      return (
                        <button
                          key={optIdx}
                          type="button"
                          disabled={showResults}
                          onClick={() => handleSelectOption(q.id, optIdx)}
                          className={`w-full text-left p-2.5 rounded-lg border text-xs transition-all ${optStyle}`}
                        >
                          <span className="font-mono mr-2 font-bold">{String.fromCharCode(65 + optIdx)}.</span>
                          {opt}
                        </button>
                      );
                    })}
                  </div>

                  {/* Explanation after submitting */}
                  {showResults && (
                    <div className="p-3 bg-white rounded-lg border border-slate-200 text-xs space-y-1">
                      <div className="font-bold text-slate-900 flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        Explanation:
                      </div>
                      <p className="text-slate-600 leading-relaxed">{q.explanation}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {!showResults && (
            <div className="text-center pt-2">
              <button
                type="button"
                onClick={() => setShowResults(true)}
                disabled={Object.keys(selectedAnswers).length === 0}
                className="px-6 py-2.5 bg-slate-900 text-white font-bold text-xs rounded-lg hover:bg-slate-800 transition-colors disabled:opacity-50"
              >
                Submit Answers & Review Explanations
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
