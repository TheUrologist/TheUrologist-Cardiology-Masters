import React, { useState } from 'react';
import { CheckCircle2, ChevronRight, Sparkles, AlertCircle, Info, Stethoscope, RefreshCw } from 'lucide-react';

interface ScenarioPreset {
  id: string;
  title: string;
  tags: string;
  description: string;
  activePath: string[];
}

const PRESET_SCENARIOS: ScenarioPreset[] = [
  {
    id: 'symptomatic-elderly',
    title: '74yo Symptomatic High-Gradient',
    tags: 'Age 74 · Mean Grad 52 · Angina',
    description: 'Concordant severe AS with exertional chest pain and preserved EF.',
    activePath: ['start', 'high-grad', 'symp-yes', 'futility-yes', 'intervene-symp', 'heart-team', 'mode-tavi'],
  },
  {
    id: 'asymptomatic-new-2025',
    title: '66yo Asymptomatic Low-Risk (NEW 2025)',
    tags: 'Age 66 · Vmax 4.4 · Normal Exercise Test · Low Risk',
    description: 'Asymptomatic high-gradient severe AS eligible for early intervention under ESC 2025 (IIa A).',
    activePath: ['start', 'high-grad', 'symp-no', 'stress-test', 'et-normal', 'asymp-new-2025', 'heart-team', 'mode-savr'],
  },
  {
    id: 'asymptomatic-low-ef',
    title: '59yo Asymptomatic LVEF 42%',
    tags: 'Age 59 · Mean Grad 48 · LVEF 42%',
    description: 'Asymptomatic severe AS with resting LVEF < 50% without other cause.',
    activePath: ['start', 'high-grad', 'symp-no', 'stress-test', 'et-normal', 'asymp-ef', 'heart-team', 'mode-savr'],
  },
  {
    id: 'lflg-dse-true-severe',
    title: '78yo Low-Flow Low-Grad (DSE Proven)',
    tags: 'Age 78 · Mean Grad 28 · SVi 29 · EF 35%',
    description: 'Low-flow low-gradient severe AS with contractile reserve confirming true severe AS.',
    activePath: ['start', 'low-flow', 'symp-yes', 'futility-yes', 'intervene-symp', 'heart-team', 'mode-tavi'],
  },
  {
    id: 'normal-flow-low-grad',
    title: '65yo Normal-Flow Low-Grad',
    tags: 'Age 65 · Mean Grad 26 · SVi 39 · EF 58%',
    description: 'Usually moderate AS or measurement discrepancy. Class III for surgery.',
    activePath: ['start', 'norm-flow'],
  },
  {
    id: 'asymp-vcble-trigger',
    title: '71yo Asymptomatic V-C-B-L-E (Vmax 5.3 m/s)',
    tags: 'Age 71 · Mean Grad 64 · BNP 4x · Asymptomatic',
    description: 'Very severe AS triggers Class IIa intervention in asymptomatic patient.',
    activePath: ['start', 'high-grad', 'symp-no', 'stress-test', 'et-normal', 'asymp-vcble', 'heart-team', 'mode-tavi'],
  },
];

export const FlowchartPanel: React.FC = () => {
  const [activeScenario, setActiveScenario] = useState<string>('symptomatic-elderly');
  const [selectedNode, setSelectedNode] = useState<string | null>('high-grad');

  const currentPreset = PRESET_SCENARIOS.find((s) => s.id === activeScenario);
  const activeNodes = currentPreset?.activePath || [];

  const isNodeActive = (nodeId: string) => activeNodes.includes(nodeId);

  const getNodeClass = (
    nodeId: string,
    recType: 'diag' | 'classI' | 'classIIa' | 'classIIb' | 'classIII' | 'center'
  ) => {
    const active = isNodeActive(nodeId);
    const selected = selectedNode === nodeId;

    let baseColors = '';
    switch (recType) {
      case 'diag':
        baseColors = 'bg-blue-50 border-blue-400 text-blue-950 dark:bg-blue-950/40 dark:border-blue-600 dark:text-blue-100';
        break;
      case 'classI':
        baseColors = 'bg-emerald-50 border-emerald-500 text-emerald-950 dark:bg-emerald-950/40 dark:border-emerald-600 dark:text-emerald-100';
        break;
      case 'classIIa':
        baseColors = 'bg-amber-50 border-amber-500 text-amber-950 dark:bg-amber-950/40 dark:border-amber-600 dark:text-amber-100';
        break;
      case 'classIIb':
        baseColors = 'bg-orange-50 border-orange-500 text-orange-950 dark:bg-orange-950/40 dark:border-orange-600 dark:text-orange-100';
        break;
      case 'classIII':
        baseColors = 'bg-rose-50 border-rose-500 text-rose-950 dark:bg-rose-950/40 dark:border-rose-600 dark:text-rose-100';
        break;
      case 'center':
        baseColors = 'bg-purple-50 border-purple-500 text-purple-950 dark:bg-purple-950/40 dark:border-purple-600 dark:text-purple-100';
        break;
    }

    const ringEffect = selected
      ? 'ring-3 ring-blue-600 ring-offset-2'
      : active
      ? 'ring-2 ring-emerald-500 ring-offset-1 shadow-sm'
      : 'opacity-75 hover:opacity-100';

    return `p-3 rounded-lg border-2 transition-all cursor-pointer ${baseColors} ${ringEffect}`;
  };

  return (
    <div className="space-y-6">
      {/* Top Controller: Interactive Patient Scenarios */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-3">
          <div>
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-600" />
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide">
                Interactive Triage Scenario Simulator
              </h3>
            </div>
            <p className="text-xs text-slate-500">
              Select an exam case scenario to highlight its exact path through the ESC 2025 decision tree:
            </p>
          </div>
          <button
            onClick={() => {
              setActiveScenario('');
              setSelectedNode(null);
            }}
            className="self-start md:self-auto text-xs font-medium text-slate-600 hover:text-slate-900 flex items-center gap-1 px-2.5 py-1 rounded-md border border-slate-200 hover:bg-slate-50 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Clear Highlight
          </button>
        </div>

        {/* Preset Badges (Interactive Buttons) */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
          {PRESET_SCENARIOS.map((scenario) => {
            const isCurrent = activeScenario === scenario.id;
            return (
              <button
                key={scenario.id}
                type="button"
                onClick={() => {
                  setActiveScenario(scenario.id);
                  setSelectedNode(scenario.activePath[scenario.activePath.length - 1]);
                }}
                className={`text-left p-2.5 rounded-lg border text-xs transition-all ${
                  isCurrent
                    ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100 hover:border-slate-300'
                }`}
              >
                <div className="font-bold truncate">{scenario.title}</div>
                <div className={`text-[10px] truncate ${isCurrent ? 'text-slate-300' : 'text-slate-500'}`}>
                  {scenario.tags}
                </div>
              </button>
            );
          })}
        </div>

        {currentPreset && (
          <div className="mt-3 pt-3 border-t border-slate-100 flex items-start gap-2 text-xs text-slate-700 bg-slate-50/80 p-2.5 rounded-lg">
            <Info className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-slate-900">Current Case: {currentPreset.title}</span> —{' '}
              {currentPreset.description}
            </div>
          </div>
        )}
      </div>

      {/* Main Flowchart Architecture */}
      <div className="bg-slate-50/60 border border-slate-200 rounded-2xl p-4 md:p-6 space-y-6">
        {/* STEP 1: Confirmation & Flow State */}
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 bg-blue-100 text-blue-800 text-[11px] font-bold rounded">
              STEP 1: DIAGNOSIS & FLOW STATE
            </span>
            <span className="text-xs text-slate-500 font-medium">
              Echocardiographic Triad & Flow Assessment
            </span>
          </div>

          <div
            id="start"
            onClick={() => setSelectedNode('start')}
            className={getNodeClass('start', 'diag')}
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-blue-700 block">
                  Entry Criteria
                </span>
                <span className="text-sm font-extrabold text-slate-900">
                  Severe Aortic Stenosis Confirmed: AVA ≤ 1.0 cm² (or Indexed AVAi ≤ 0.60 cm²/m²)
                </span>
              </div>
              <span className="text-xs bg-blue-100 text-blue-800 font-semibold px-2 py-1 rounded shrink-0">
                Continuous Doppler + Continuity Eq
              </span>
            </div>
          </div>

          {/* Flow Split: 3 Branches */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
            {/* Branch 1: High Gradient */}
            <div
              id="high-grad"
              onClick={() => setSelectedNode('high-grad')}
              className={getNodeClass('high-grad', 'diag')}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-[11px] font-bold text-blue-800 uppercase">Branch A</span>
                <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded">
                  Concordant
                </span>
              </div>
              <div className="font-bold text-slate-900 text-sm">High-Gradient Severe AS</div>
              <div className="text-xs text-slate-600 mt-1 font-mono">
                Mean Grad ≥ 40 mmHg • Vmax ≥ 4.0 m/s
              </div>
              <p className="text-[11px] text-slate-500 mt-2">
                Concordant severe AS established. No further hemodynamics needed. Proceed directly to symptom check.
              </p>
            </div>

            {/* Branch 2: Low-Flow Low-Gradient */}
            <div
              id="low-flow"
              onClick={() => setSelectedNode('low-flow')}
              className={getNodeClass('low-flow', 'diag')}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-[11px] font-bold text-amber-800 uppercase">Branch B</span>
                <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.5 rounded">
                  Discordant
                </span>
              </div>
              <div className="font-bold text-slate-900 text-sm">Low-Flow Low-Gradient (LFLG)</div>
              <div className="text-xs text-slate-600 mt-1 font-mono">
                Mean Grad &lt; 40 mmHg • SVi ≤ 35 mL/m²
              </div>
              <p className="text-[11px] text-slate-500 mt-2">
                • If EF &lt; 50%: Dobutamine Stress Echo (Flow reserve ΔSV ≥ 20%).<br />
                • If EF ≥ 50% or no reserve: Non-contrast CT Calcium score.
              </p>
            </div>

            {/* Branch 3: Normal-Flow Low-Gradient */}
            <div
              id="norm-flow"
              onClick={() => setSelectedNode('norm-flow')}
              className={getNodeClass('norm-flow', 'classIII')}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-[11px] font-bold text-rose-800 uppercase">Branch C</span>
                <span className="text-[10px] bg-rose-100 text-rose-800 font-bold px-1.5 py-0.5 rounded">
                  Surveillance
                </span>
              </div>
              <div className="font-bold text-slate-900 text-sm">Normal-Flow Low-Gradient</div>
              <div className="text-xs text-slate-600 mt-1 font-mono">
                Mean Grad &lt; 40 mmHg • SVi &gt; 35 mL/m²
              </div>
              <p className="text-[11px] text-slate-500 mt-2">
                Usually MODERATE AS. Re-evaluate LVOT measurement & BP. Invasive surgery futile (Class III). Active surveillance.
              </p>
            </div>
          </div>
        </div>

        {/* STEP 2: Symptom Assessment & Adverse Triggers */}
        <div className="space-y-4 pt-3 border-t border-slate-200">
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[11px] font-bold rounded">
              STEP 2: SYMPTOM ASSESSMENT & ASYMPTOMATIC TRIGGERS
            </span>
            <span className="text-xs text-slate-500 font-medium">
              Symptomatic vs Asymptomatic Clinical Branching
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Column 1: Symptomatic Pathway */}
            <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <span className="font-bold text-slate-900 text-xs uppercase tracking-wider flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-600" />
                  Symptomatic Pathway (Angina, Dyspnea, Syncope)
                </span>
                <span className="text-[11px] text-slate-500">History & Exam</span>
              </div>

              {/* Futility check */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <div
                  id="futility-no"
                  onClick={() => setSelectedNode('futility-no')}
                  className={getNodeClass('futility-no', 'classIII')}
                >
                  <div className="font-bold text-rose-900">Life Expectancy &lt; 1 Year</div>
                  <div className="text-[11px] text-slate-600 mt-0.5">Severe frailty or futility</div>
                  <div className="mt-1 font-bold text-rose-700">Class III: Palliative Care</div>
                </div>

                <div
                  id="futility-yes"
                  onClick={() => setSelectedNode('futility-yes')}
                  className={getNodeClass('futility-yes', 'classI')}
                >
                  <div className="font-bold text-emerald-900">Life Expectancy &gt; 1 Year</div>
                  <div className="text-[11px] text-slate-600 mt-0.5">Meaningful quality of life expected</div>
                  <div className="mt-1 font-bold text-emerald-700">Class I: Intervention Mandated</div>
                </div>
              </div>

              {/* Intervention recommendation box */}
              <div
                id="intervene-symp"
                onClick={() => setSelectedNode('intervene-symp')}
                className={getNodeClass('intervene-symp', 'classI')}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-extrabold text-emerald-900 uppercase">
                    Intervention Recommended
                  </span>
                  <span className="text-xs font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                    Class I, LoE B
                  </span>
                </div>
                <p className="text-xs text-slate-700">
                  • High-gradient symptomatic severe AS: <span className="font-bold text-emerald-900">Class I, LoE B</span><br />
                  • Low-flow low-gradient with reduced EF (true severe): <span className="font-bold text-emerald-900">Class I, LoE B</span><br />
                  • Low-flow low-gradient with preserved EF: <span className="font-bold text-amber-800">Class IIa, LoE B</span>
                </p>
                <div className="mt-2 text-[11px] text-slate-500 italic">
                  → Routes directly to Heart Team for TAVI vs SAVR mode selection.
                </div>
              </div>
            </div>

            {/* Column 2: Asymptomatic Pathway */}
            <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <span className="font-bold text-slate-900 text-xs uppercase tracking-wider flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-blue-600" />
                  Asymptomatic Pathway (Sedentary / Denies Symptoms)
                </span>
                <span className="text-[11px] text-slate-500">Standardized Exercise Test</span>
              </div>

              {/* Stress test box */}
              <div
                id="stress-test"
                onClick={() => setSelectedNode('stress-test')}
                className={getNodeClass('stress-test', 'diag')}
              >
                <div className="font-bold text-xs text-blue-900">
                  Standardized Treadmill / Bike Exercise Testing
                </div>
                <div className="text-[11px] text-slate-600 mt-1">
                  Unmasks hidden symptoms in ~30% of "asymptomatic" patients. Reclassifies as symptomatic (Class I, LoE B) if exertional symptoms occur.
                </div>
                <div className="mt-1 text-[11px] text-amber-800 font-semibold">
                  • Sustained drop in SBP &gt; 20 mmHg → Intervention Considered (Class IIa, LoE C)
                </div>
              </div>

              {/* Asymptomatic Triggers List */}
              <div className="space-y-2">
                <div className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                  Triggers in True Asymptomatic Patients:
                </div>

                {/* Trigger 1: LVEF < 50% */}
                <div
                  id="asymp-ef"
                  onClick={() => setSelectedNode('asymp-ef')}
                  className={getNodeClass('asymp-ef', 'classI')}
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-emerald-950">LVEF &lt; 50% without other cause</span>
                    <span className="bg-emerald-100 text-emerald-900 font-bold px-1.5 py-0.5 rounded text-[10px]">
                      Class I, LoE B
                    </span>
                  </div>
                </div>

                {/* Trigger 2: Concomitant CABG */}
                <div
                  id="asymp-cabg"
                  onClick={() => setSelectedNode('asymp-cabg')}
                  className={getNodeClass('asymp-cabg', 'classI')}
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-emerald-950">Concomitant CABG, Ascending Aorta, or Other Valve</span>
                    <span className="bg-emerald-100 text-emerald-900 font-bold px-1.5 py-0.5 rounded text-[10px]">
                      Class I, LoE C
                    </span>
                  </div>
                </div>

                {/* Trigger 3: NEW 2025 High-Grad Low-Risk */}
                <div
                  id="asymp-new-2025"
                  onClick={() => setSelectedNode('asymp-new-2025')}
                  className={getNodeClass('asymp-new-2025', 'classIIa')}
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-amber-950 flex items-center gap-1">
                      High-Grad + LVEF ≥ 50% + Normal Exercise Test + Low Risk
                      <span className="bg-emerald-700 text-white text-[9px] font-extrabold px-1 rounded">
                        NEW 2025
                      </span>
                    </span>
                    <span className="bg-amber-100 text-amber-900 font-bold px-1.5 py-0.5 rounded text-[10px]">
                      Class IIa, LoE A
                    </span>
                  </div>
                  <div className="text-[10px] text-amber-800 mt-0.5">
                    RECOVERY & AVATAR trials: Early intervention superior to watchful waiting in low operative risk.
                  </div>
                </div>

                {/* Trigger 4: V-C-B-L-E Triggers */}
                <div
                  id="asymp-vcble"
                  onClick={() => setSelectedNode('asymp-vcble')}
                  className={getNodeClass('asymp-vcble', 'classIIa')}
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-amber-950">V-C-B-L-E Triggers (Grad ≥ 60, Ca++, BNP &gt; 3x, EF &lt; 55%)</span>
                    <span className="bg-amber-100 text-amber-900 font-bold px-1.5 py-0.5 rounded text-[10px]">
                      Class IIa, LoE B
                    </span>
                  </div>
                </div>

                {/* Surveillance if no triggers */}
                <div
                  id="surveillance"
                  onClick={() => setSelectedNode('surveillance')}
                  className={getNodeClass('surveillance', 'classI')}
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-emerald-950">No Triggers Met: Active Valve Clinic Surveillance</span>
                    <span className="bg-emerald-100 text-emerald-900 font-bold px-1.5 py-0.5 rounded text-[10px]">
                      Review q6 Months
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* STEP 3: Mode Selection (TAVI vs SAVR) */}
        <div className="space-y-4 pt-3 border-t border-slate-200">
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 bg-purple-100 text-purple-800 text-[11px] font-bold rounded">
              STEP 3: MODE SELECTION (SAVR vs TAVI)
            </span>
            <span className="text-xs text-slate-500 font-medium">
              Heart Valve Center & Heart Team Age 70 Algorithm
            </span>
          </div>

          <div
            id="heart-team"
            onClick={() => setSelectedNode('heart-team')}
            className={getNodeClass('heart-team', 'center')}
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-purple-700 block">
                  Multidisciplinary Assessment
                </span>
                <span className="text-sm font-bold text-purple-950">
                  Heart Team Decision: Cardiologist + Cardiac Surgeon + Imaging Specialist + Geriatrician
                </span>
              </div>
              <span className="text-xs font-mono text-purple-700 bg-purple-100 px-2 py-0.5 rounded shrink-0">
                STS / EuroSCORE II Cutoff: 4%
              </span>
            </div>
          </div>

          {/* Mode Selection Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {/* TAVI */}
            <div
              id="mode-tavi"
              onClick={() => setSelectedNode('mode-tavi')}
              className={getNodeClass('mode-tavi', 'classI')}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-extrabold text-emerald-900 uppercase">TAVI Recommended</span>
                <span className="text-xs bg-emerald-100 text-emerald-900 font-bold px-1.5 py-0.5 rounded">
                  Class I, LoE A
                </span>
              </div>
              <div className="text-xs font-semibold text-slate-800 mt-1">
                Age ≥ 70 Years OR High Surgical Risk (STS ≥ 4%)
              </div>
              <p className="text-[11px] text-slate-600 mt-1">
                Transfemoral route is standard first-line. Low-profile delivery, pre-procedural CT for annular sizing & coronary ostial heights.
              </p>
              <div className="mt-2 text-[10px] font-bold text-emerald-800">
                ★ ESC 2025 Update: Lowered age threshold from 75 to 70!
              </div>
            </div>

            {/* SAVR */}
            <div
              id="mode-savr"
              onClick={() => setSelectedNode('mode-savr')}
              className={getNodeClass('mode-savr', 'classI')}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-extrabold text-emerald-900 uppercase">SAVR Recommended</span>
                <span className="text-xs bg-emerald-100 text-emerald-900 font-bold px-1.5 py-0.5 rounded">
                  Class I, LoE B
                </span>
              </div>
              <div className="text-xs font-semibold text-slate-800 mt-1">
                Age &lt; 70 Years AND Low Surgical Risk (STS &lt; 4%)
              </div>
              <p className="text-[11px] text-slate-600 mt-1">
                Surgical aortic valve replacement. Mechanical valve favored if age &lt; 60 and no anticoagulation contraindication. Bioprosthetic if age &ge; 65.
              </p>
            </div>

            {/* Bicuspid / Intermediate */}
            <div
              id="mode-bicuspid"
              onClick={() => setSelectedNode('mode-bicuspid')}
              className={getNodeClass('mode-bicuspid', 'classIIb')}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-extrabold text-orange-950 uppercase">Bicuspid / Intermediate</span>
                <span className="text-xs bg-orange-100 text-orange-900 font-bold px-1.5 py-0.5 rounded">
                  Class IIb, LoE B
                </span>
              </div>
              <div className="text-xs font-semibold text-slate-800 mt-1">
                Bicuspid Anatomy + High Risk Candidate
              </div>
              <p className="text-[11px] text-slate-600 mt-1">
                TAVI may be considered if anatomical features suitable (exclude severe raphe calcification or extreme annular asymmetry).
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
