import React from 'react';
import { RecommendationClass } from '../types/cardiology';

interface GuidelineLegendProps {
  selectedClass?: RecommendationClass | 'All';
  onSelectClass?: (recClass: RecommendationClass | 'All') => void;
  interactive?: boolean;
}

export const GuidelineLegend: React.FC<GuidelineLegendProps> = ({
  selectedClass = 'All',
  onSelectClass,
  interactive = false,
}) => {
  const legendItems: {
    recClass: RecommendationClass;
    label: string;
    description: string;
    bgClass: string;
    borderClass: string;
    textClass: string;
    dotClass: string;
  }[] = [
    {
      recClass: 'Class I',
      label: 'Class I',
      description: 'Mandatory / Recommended / 1st-line',
      bgClass: 'bg-emerald-50 dark:bg-emerald-950/30',
      borderClass: 'border-emerald-500',
      textClass: 'text-emerald-800 dark:text-emerald-300',
      dotClass: 'bg-emerald-600',
    },
    {
      recClass: 'Class IIa',
      label: 'Class IIa',
      description: 'Should be considered / High likelihood',
      bgClass: 'bg-amber-50 dark:bg-amber-950/30',
      borderClass: 'border-amber-500',
      textClass: 'text-amber-800 dark:text-amber-300',
      dotClass: 'bg-amber-500',
    },
    {
      recClass: 'Class IIb',
      label: 'Class IIb',
      description: 'May be considered / Equivocal',
      bgClass: 'bg-orange-50 dark:bg-orange-950/30',
      borderClass: 'border-orange-500',
      textClass: 'text-orange-800 dark:text-orange-300',
      dotClass: 'bg-orange-500',
    },
    {
      recClass: 'Class III',
      label: 'Class III',
      description: 'Harm / Futile / Contraindicated',
      bgClass: 'bg-rose-50 dark:bg-rose-950/30',
      borderClass: 'border-rose-500',
      textClass: 'text-rose-800 dark:text-rose-300',
      dotClass: 'bg-rose-600',
    },
    {
      recClass: 'Diagnostic',
      label: 'Diagnostic / Echo',
      description: 'Criteria / Thresholds / Modalities',
      bgClass: 'bg-blue-50 dark:bg-blue-950/30',
      borderClass: 'border-blue-500',
      textClass: 'text-blue-800 dark:text-blue-300',
      dotClass: 'bg-blue-600',
    },
  ];

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-3 md:p-4 shadow-xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2 pb-2 border-b border-slate-100">
        <div className="text-xs font-semibold text-slate-700 tracking-wider">
          ESC / EACTS 2025 GUIDELINE COLOR CODING
        </div>
        <div className="text-xs text-slate-500">
          Standardized visual language for Cairo University Master's Exam
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
        {legendItems.map((item) => {
          const isSelected = selectedClass === item.recClass || selectedClass === 'All';
          const isCurrentActive = selectedClass === item.recClass;

          return (
            <button
              key={item.recClass}
              type="button"
              disabled={!interactive}
              onClick={() => onSelectClass && onSelectClass(isCurrentActive ? 'All' : item.recClass)}
              className={`text-left p-2.5 rounded-lg border transition-all ${item.bgClass} ${item.borderClass} ${
                interactive
                  ? 'cursor-pointer hover:shadow-xs active:scale-98'
                  : 'cursor-default'
              } ${isSelected ? 'opacity-100 ring-1 ring-offset-1 ring-slate-400' : 'opacity-40'}`}
            >
              <div className="flex items-center gap-1.5 mb-1">
                <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${item.dotClass}`} />
                <span className={`text-xs font-bold ${item.textClass}`}>
                  {item.label}
                </span>
              </div>
              <p className="text-[11px] leading-tight text-slate-600 line-clamp-2">
                {item.description}
              </p>
            </button>
          );
        })}
      </div>
    </div>
  );
};
