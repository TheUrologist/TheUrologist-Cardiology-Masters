import React from 'react';
import { Printer } from 'lucide-react';

interface HeaderProps {
  currentTab: 'severeAS' | 'aorticRegurg' | 'mitralRegurg' | 'simulator' | 'examBooklet';
  onSelectTab: (tab: 'severeAS' | 'aorticRegurg' | 'mitralRegurg' | 'simulator' | 'examBooklet') => void;
  onPrintNotes: () => void;
}

export const Header: React.FC<HeaderProps> = ({ currentTab, onSelectTab, onPrintNotes }) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between gap-8 h-16">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            onSelectTab('severeAS');
          }}
          className="text-lg font-extrabold tracking-tight text-slate-900 whitespace-nowrap shrink-0 flex items-center gap-2"
        >
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 inline-block" />
          <span>CardioMaster 2025</span>
        </a>

        {/* Zone 2: 4-5 concise single-line text links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-semibold text-slate-600">
          <button
            type="button"
            onClick={() => onSelectTab('severeAS')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 border-b-2 ${
              currentTab === 'severeAS'
                ? 'border-emerald-600 text-slate-900'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            Severe AS (Q1.1)
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('aorticRegurg')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 border-b-2 ${
              currentTab === 'aorticRegurg'
                ? 'border-emerald-600 text-slate-900'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            Aortic Regurg
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('mitralRegurg')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 border-b-2 ${
              currentTab === 'mitralRegurg'
                ? 'border-emerald-600 text-slate-900'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            Mitral Regurg
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('simulator')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 border-b-2 ${
              currentTab === 'simulator'
                ? 'border-emerald-600 text-slate-900'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            Triage Simulator
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('examBooklet')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 border-b-2 ${
              currentTab === 'examBooklet'
                ? 'border-emerald-600 text-slate-900'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            Exam Booklet
          </button>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={onPrintNotes}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 shadow-xs"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Cheat Sheet</span>
          </button>
        </div>
      </div>

      {/* Mobile nav drawer strip */}
      <div className="md:hidden flex items-center overflow-x-auto gap-2 px-4 py-2 border-t border-slate-100 bg-slate-50/80 text-xs">
        <button
          type="button"
          onClick={() => onSelectTab('severeAS')}
          className={`px-2.5 py-1 rounded whitespace-nowrap font-semibold ${
            currentTab === 'severeAS' ? 'bg-slate-900 text-white' : 'text-slate-700'
          }`}
        >
          Severe AS
        </button>
        <button
          type="button"
          onClick={() => onSelectTab('aorticRegurg')}
          className={`px-2.5 py-1 rounded whitespace-nowrap font-semibold ${
            currentTab === 'aorticRegurg' ? 'bg-slate-900 text-white' : 'text-slate-700'
          }`}
        >
          Aortic Regurg
        </button>
        <button
          type="button"
          onClick={() => onSelectTab('mitralRegurg')}
          className={`px-2.5 py-1 rounded whitespace-nowrap font-semibold ${
            currentTab === 'mitralRegurg' ? 'bg-slate-900 text-white' : 'text-slate-700'
          }`}
        >
          Mitral Regurg
        </button>
        <button
          type="button"
          onClick={() => onSelectTab('simulator')}
          className={`px-2.5 py-1 rounded whitespace-nowrap font-semibold ${
            currentTab === 'simulator' ? 'bg-slate-900 text-white' : 'text-slate-700'
          }`}
        >
          Simulator
        </button>
        <button
          type="button"
          onClick={() => onSelectTab('examBooklet')}
          className={`px-2.5 py-1 rounded whitespace-nowrap font-semibold ${
            currentTab === 'examBooklet' ? 'bg-slate-900 text-white' : 'text-slate-700'
          }`}
        >
          Booklet
        </button>
      </div>
    </header>
  );
};
