import React, { useState } from 'react';
import { AS_METRIC_NUMBER_LINE, VCBLE_MNEMONIC } from '../data/severeASData';
import { MetricNumberItem } from '../types/cardiology';
import { Bookmark, Sparkles, ChevronDown, ChevronUp, AlertCircle, Compass } from 'lucide-react';

export const NumberLinePanel: React.FC = () => {
  const [selectedMetric, setSelectedMetric] = useState<MetricNumberItem>(AS_METRIC_NUMBER_LINE[2]); // Default 1.0 AVA
  const [expandedLetter, setExpandedLetter] = useState<string>('V');

  return (
    <div className="space-y-8">
      {/* SECTION 1: The Asymptomatic Adverse Features Mnemonic "V-C-B-L-E" */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 md:p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-amber-700 uppercase tracking-wider">
                PANEL 4A: HIGH-YIELD MNEMONIC
              </span>
              <span className="px-2 py-0.5 bg-amber-100 text-amber-900 text-[10px] font-extrabold rounded">
                CLASS IIa TRIGGERS
              </span>
            </div>
            <h3 className="text-base font-extrabold text-slate-900 mt-0.5">
              The Asymptomatic Adverse Features Mnemonic: "V-C-B-L-E"
            </h3>
          </div>
          <div className="text-xs text-slate-500 font-mono">
            ESC/EACTS 2025 Guideline Risk Markers
          </div>
        </div>

        {/* Mnemonic Horizontal Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
          {VCBLE_MNEMONIC.map((item) => {
            const isSelected = expandedLetter === item.letter;
            return (
              <button
                key={item.letter}
                type="button"
                onClick={() => setExpandedLetter(item.letter)}
                className={`text-left p-3 rounded-xl border transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-amber-500 text-white border-amber-600 shadow-md ring-2 ring-amber-400 ring-offset-1'
                    : 'bg-amber-50 text-slate-800 border-amber-200 hover:bg-amber-100/70'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className={`text-2xl font-black font-mono ${isSelected ? 'text-white' : 'text-amber-800'}`}>
                    {item.letter}
                  </span>
                  <span
                    className={`text-[9px] font-extrabold px-1.5 py-0.5 rounded ${
                      isSelected ? 'bg-amber-700 text-white' : 'bg-amber-200 text-amber-900'
                    }`}
                  >
                    {item.recClass}
                  </span>
                </div>
                <div className={`text-xs font-bold mt-1 line-clamp-1 ${isSelected ? 'text-amber-100' : 'text-slate-800'}`}>
                  {item.title}
                </div>
              </button>
            );
          })}
        </div>

        {/* Detailed Explanation for Expanded Mnemonic Letter */}
        {(() => {
          const activeItem = VCBLE_MNEMONIC.find((m) => m.letter === expandedLetter) || VCBLE_MNEMONIC[0];
          return (
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-xs space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-amber-600 text-white flex items-center justify-center font-bold text-xs">
                    {activeItem.letter}
                  </span>
                  {activeItem.title}
                </span>
                <span className="bg-amber-100 text-amber-900 text-xs font-bold px-2 py-0.5 rounded border border-amber-300">
                  {activeItem.recClass}, Level of Evidence {activeItem.loe}
                </span>
              </div>
              <div className="font-mono text-slate-800 font-semibold bg-white p-2.5 rounded border border-slate-200">
                Criteria: {activeItem.criteria}
              </div>
              <p className="text-slate-600 leading-relaxed">
                <span className="font-bold text-slate-800">Pathophysiologic Rationale: </span>
                {activeItem.rationale}
              </p>
            </div>
          );
        })()}
      </div>

      {/* SECTION 2: The Severe AS Metric Number Line */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 md:p-6 shadow-xs space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-blue-700 uppercase tracking-wider">
                PANEL 4B: MENTAL NUMBER LINE
              </span>
              <span className="px-2 py-0.5 bg-blue-100 text-blue-900 text-[10px] font-bold rounded">
                CRITICAL THRESHOLDS
              </span>
            </div>
            <h3 className="text-base font-extrabold text-slate-900 mt-0.5">
              The Severe AS Metric Number Line
            </h3>
            <p className="text-xs text-slate-500">
              Instant mental anchor of numerical cutoffs in hemodynamic order:
            </p>
          </div>
          <div className="text-xs font-mono text-slate-500">
            0.25 → 0.6 → 1.0 → 4.0 → 5.0 → 60
          </div>
        </div>

        {/* Visual Axis Line Diagram */}
        <div className="relative py-8 px-4 bg-slate-950 rounded-xl text-white overflow-x-auto">
          {/* Main Axis Wire */}
          <div className="relative min-w-[620px] h-2 bg-gradient-to-r from-blue-500 via-emerald-500 to-rose-500 rounded-full my-6">
            {/* Markers on the Number Line */}
            {AS_METRIC_NUMBER_LINE.map((metric, idx) => {
              const isCurrent = selectedMetric.value === metric.value;
              // Percentage along the horizontal wire
              const positions = [5, 22, 40, 60, 78, 95];
              const leftPos = positions[idx];

              return (
                <div
                  key={metric.value}
                  style={{ left: `${leftPos}%` }}
                  className="absolute -top-3 -translate-x-1/2 flex flex-col items-center group cursor-pointer"
                  onClick={() => setSelectedMetric(metric)}
                >
                  {/* Ticking Pin */}
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-xs transition-transform ${
                      isCurrent
                        ? 'bg-white text-slate-950 ring-4 ring-emerald-400 scale-125'
                        : 'bg-slate-800 text-slate-200 hover:scale-110 hover:bg-slate-700'
                    }`}
                  >
                    {idx + 1}
                  </div>

                  {/* Marker Label */}
                  <div className="mt-2 text-center whitespace-nowrap">
                    <span
                      className={`text-xs font-mono font-extrabold px-1.5 py-0.5 rounded ${
                        isCurrent ? 'bg-emerald-500 text-slate-950 font-black' : 'text-slate-300'
                      }`}
                    >
                      {metric.label}
                    </span>
                    <div className="text-[10px] text-slate-400 font-sans mt-0.5">
                      {metric.metricName.split('(')[0].trim()}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected Metric Breakdown Card */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-xs space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 pb-2">
            <div>
              <span className="text-[11px] font-bold text-blue-700 uppercase tracking-wider block">
                Metric Details
              </span>
              <span className="text-sm font-extrabold text-slate-900">
                {selectedMetric.metricName} = {selectedMetric.label} {selectedMetric.unit}
              </span>
            </div>
            <span
              className={`text-xs font-bold px-2.5 py-1 rounded-md shrink-0 ${
                selectedMetric.thresholdType === 'Very Severe'
                  ? 'bg-rose-100 text-rose-900 border border-rose-300'
                  : 'bg-emerald-100 text-emerald-900 border border-emerald-300'
              }`}
            >
              {selectedMetric.thresholdType} Cutoff
            </span>
          </div>

          <p className="text-slate-700 leading-relaxed">
            <span className="font-bold text-slate-900">Clinical Significance: </span>
            {selectedMetric.clinicalMeaning}
          </p>

          <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-lg text-amber-950 text-xs flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold text-amber-900">Cairo Master's Exam Trap: </span>
              {selectedMetric.examTrapNote}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
