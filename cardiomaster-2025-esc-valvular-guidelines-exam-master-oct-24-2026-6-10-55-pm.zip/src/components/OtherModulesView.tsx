import React, { useState } from 'react';
import { MODULE_AORTIC_REGURG, MODULE_MITRAL_REGURG, ValvularModule } from '../data/otherModulesData';
import { RecommendationClass } from '../types/cardiology';
import { AlertCircle, FileText, CheckCircle2, Copy, Check } from 'lucide-react';

interface OtherModulesViewProps {
  moduleId: 'ar' | 'mr';
}

export const OtherModulesView: React.FC<OtherModulesViewProps> = ({ moduleId }) => {
  const currentModule: ValvularModule = moduleId === 'ar' ? MODULE_AORTIC_REGURG : MODULE_MITRAL_REGURG;
  const [copied, setCopied] = useState<boolean>(false);

  const getClassBadgeStyle = (recClass: RecommendationClass) => {
    switch (recClass) {
      case 'Class I':
        return 'bg-emerald-100 text-emerald-800 border-emerald-300';
      case 'Class IIa':
        return 'bg-amber-100 text-amber-800 border-amber-300';
      case 'Class IIb':
        return 'bg-orange-100 text-orange-800 border-orange-300';
      case 'Class III':
        return 'bg-rose-100 text-rose-800 border-rose-300';
      default:
        return 'bg-blue-100 text-blue-800 border-blue-300';
    }
  };

  const handleCopyNotes = () => {
    const summary = `${currentModule.code}: ${currentModule.title}
${currentModule.description}

DIAGNOSTIC CRITERIA:
${currentModule.diagnosticCriteria.map((c) => `• ${c.label}: ${c.threshold} (${c.notes})`).join('\n')}

GUIDELINE RECOMMENDATIONS:
${currentModule.recommendations.map((r) => `• [${r.recClass}, LoE ${r.loe}] ${r.indication} -> ${r.details}`).join('\n')}

EXAM TRAPS:
${currentModule.examTraps.map((t) => `• TRAP: ${t.trap}\n  SOLUTION: ${t.solution}`).join('\n')}`;

    navigator.clipboard.writeText(summary);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Module Title Banner */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 md:p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-blue-700 uppercase tracking-wider">
              {currentModule.code}
            </span>
            <span className="px-2 py-0.5 bg-blue-100 text-blue-900 text-[10px] font-bold rounded">
              {currentModule.badge}
            </span>
          </div>
          <h2 className="text-xl font-black text-slate-900 mt-1">{currentModule.title}</h2>
          <p className="text-xs text-slate-600 mt-0.5">{currentModule.description}</p>
        </div>

        <button
          type="button"
          onClick={handleCopyNotes}
          className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 transition-colors shrink-0"
        >
          {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
          <span>{copied ? 'Copied Module Notes' : 'Copy Full Module Notes'}</span>
        </button>
      </div>

      {/* Panel 1 & 2: Diagnostic Criteria & Thresholds */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 md:p-6 shadow-xs space-y-4">
        <div className="border-b border-slate-100 pb-2">
          <span className="text-xs font-bold text-blue-700 uppercase tracking-wider block">
            PANEL 1: INTEGRATIVE ECHOCARDIOGRAPHIC CRITERIA
          </span>
          <h3 className="text-base font-extrabold text-slate-900">
            Multiparametric Severity Grading
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {currentModule.diagnosticCriteria.map((crit, idx) => (
            <div key={idx} className="p-3 rounded-lg border border-blue-200 bg-blue-50/40 space-y-1">
              <div className="text-[11px] font-bold text-blue-900 uppercase tracking-wide">
                {crit.label}
              </div>
              <div className="text-sm font-black font-mono text-blue-950">{crit.threshold}</div>
              <p className="text-[11px] text-slate-600 leading-tight">{crit.notes}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Panel 3: Color-Coded Recommendation Table */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 md:p-6 shadow-xs space-y-4">
        <div className="border-b border-slate-100 pb-2">
          <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider block">
            PANEL 2: ESC 2025 INTERVENTION SPECTRUM
          </span>
          <h3 className="text-base font-extrabold text-slate-900">
            Surgical & Transcatheter Indications
          </h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-slate-700">
                <th className="py-2.5 px-3 font-bold">Category</th>
                <th className="py-2.5 px-3 font-bold">Clinical Setting & Indication</th>
                <th className="py-2.5 px-3 font-bold text-center">Class</th>
                <th className="py-2.5 px-3 font-bold text-center">LoE</th>
                <th className="py-2.5 px-3 font-bold">Specific Evidence / Note</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {currentModule.recommendations.map((rec) => (
                <tr key={rec.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3 px-3 align-top font-bold text-slate-700">
                    {rec.category}
                  </td>
                  <td className="py-3 px-3 align-top text-slate-900">
                    <div className="font-bold">{rec.indication}</div>
                    <div className="text-[11px] text-slate-600 mt-1">{rec.details}</div>
                  </td>
                  <td className="py-3 px-3 align-top text-center">
                    <span
                      className={`inline-block px-2.5 py-0.5 rounded border font-extrabold text-[11px] whitespace-nowrap ${getClassBadgeStyle(
                        rec.recClass
                      )}`}
                    >
                      {rec.recClass}
                    </span>
                  </td>
                  <td className="py-3 px-3 align-top text-center font-mono font-bold text-xs text-slate-800">
                    {rec.loe}
                  </td>
                  <td className="py-3 px-3 align-top text-[11px] text-slate-600">
                    Cairo Mark Weight: ~{rec.examMarks} Mark(s)
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Panel 4: Hand-drawn Exam Booklet Structure */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 md:p-6 shadow-xs space-y-3">
        <div className="border-b border-slate-100 pb-2">
          <span className="text-xs font-bold text-amber-700 uppercase tracking-wider block">
            PANEL 3: 30-SECOND HAND-DRAWN EXAM BOOKLET LAYOUT
          </span>
          <h3 className="text-base font-extrabold text-slate-900">
            How to Layout the Answer Sheet for {currentModule.title}
          </h3>
        </div>

        <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-2 text-xs font-mono">
          {currentModule.handDrawnSummary.map((item, idx) => (
            <div key={idx} className="flex items-start gap-2">
              <span className="text-amber-700 font-bold shrink-0">[{idx + 1}]</span>
              <span className="text-slate-800">{item}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Panel 5: Exam Traps for this Module */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 md:p-6 shadow-xs space-y-4">
        <div className="border-b border-slate-100 pb-2">
          <span className="text-xs font-bold text-rose-700 uppercase tracking-wider block">
            PANEL 4: HIGH-YIELD EXAM TRAPS
          </span>
          <h3 className="text-base font-extrabold text-slate-900">
            Frequently Penalized Conceptual Misunderstandings
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {currentModule.examTraps.map((trap, idx) => (
            <div key={idx} className="p-4 rounded-xl border border-rose-200 bg-rose-50/40 space-y-2 text-xs">
              <div className="font-bold text-rose-950 text-sm flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                {trap.title}
              </div>
              <div className="p-2 bg-white rounded border border-rose-100 text-rose-900 font-semibold">
                Trap: {trap.trap}
              </div>
              <div className="p-2 bg-emerald-50 rounded border border-emerald-100 text-emerald-950">
                Correct Guideline Answer: {trap.solution}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
