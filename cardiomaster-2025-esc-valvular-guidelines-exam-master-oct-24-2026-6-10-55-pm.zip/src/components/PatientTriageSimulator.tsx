import React, { useState } from 'react';
import { RecommendationClass, LevelOfEvidence } from '../types/cardiology';
import { Calculator, ArrowRight, CheckCircle, AlertTriangle, ShieldCheck, Copy, Check } from 'lucide-react';

export const PatientTriageSimulator: React.FC = () => {
  // Input parameters
  const [age, setAge] = useState<number>(72);
  const [ava, setAva] = useState<number>(0.85);
  const [bsa, setBsa] = useState<number>(1.8);
  const [meanGrad, setMeanGrad] = useState<number>(45);
  const [vMax, setVMax] = useState<number>(4.2);
  const [svi, setSvi] = useState<number>(38);
  const [lvef, setLvef] = useState<number>(55);
  const [hasSymptoms, setHasSymptoms] = useState<boolean>(true);
  const [exerciseResult, setExerciseResult] = useState<'normal' | 'symptoms' | 'bpDrop'>('normal');
  const [surgicalRiskPercent, setSurgicalRiskPercent] = useState<number>(2.5); // EuroSCORE II or STS
  const [isBicuspid, setIsBicuspid] = useState<boolean>(false);
  const [hasConcomitantSurgery, setHasConcomitantSurgery] = useState<boolean>(false);
  const [isLifeExpectancyOver1Year, setIsLifeExpectancyOver1Year] = useState<boolean>(true);

  // Advanced markers (V-C-B-L-E)
  const [bnpElevated3x, setBnpElevated3x] = useState<boolean>(false);
  const [rapidProgression, setRapidProgression] = useState<boolean>(false);

  const [copied, setCopied] = useState<boolean>(false);

  // Computations
  const indexedAva = Number((ava / bsa).toFixed(2));
  const isSevereByAva = ava <= 1.0 || indexedAva <= 0.60;
  const isHighGradient = meanGrad >= 40 || vMax >= 4.0;
  const isLowFlow = svi <= 35;

  let phenotype = 'Unknown';
  let recClass: RecommendationClass = 'Diagnostic';
  let loe: LevelOfEvidence = 'B';
  let recommendationSummary = '';
  let procedureMode = '';
  let examNotes = '';

  if (!isSevereByAva) {
    phenotype = 'Mild-to-Moderate Aortic Stenosis';
    recClass = 'Class III';
    loe = 'C';
    recommendationSummary = 'Aortic valve area does not meet severe threshold (AVA > 1.0 cm² and indexed AVA > 0.60 cm²/m²).';
    procedureMode = 'Conservative Medical Management & Surveillance';
    examNotes = 'Do not proceed with TAVI/SAVR for non-severe AS. Re-evaluate with serial echocardiography in 1-2 years.';
  } else if (isHighGradient) {
    phenotype = 'Concordant High-Gradient Severe AS';

    if (hasSymptoms) {
      if (!isLifeExpectancyOver1Year) {
        recClass = 'Class III';
        loe = 'B';
        recommendationSummary = 'Futility: Life expectancy < 1 year or severe comorbidities limiting quality of life.';
        procedureMode = 'Palliative & Supportive Medical Care';
        examNotes = 'Invasive intervention is contraindicated when futile.';
      } else {
        recClass = 'Class I';
        loe = 'B';
        recommendationSummary = 'Symptomatic high-gradient severe aortic stenosis.';

        if (hasConcomitantSurgery) {
          procedureMode = 'Concomitant SAVR (Class I, LoE C)';
          examNotes = 'Surgical replacement indicated during open cardiac surgery.';
        } else if (age >= 70 || surgicalRiskPercent >= 4.0) {
          if (isBicuspid) {
            recClass = 'Class IIb';
            loe = 'B';
            procedureMode = 'Heart Team Evaluation: TAVI may be considered (Class IIb, LoE B) vs SAVR';
            examNotes = 'Bicuspid anatomy in high-risk candidate warrants CT sizing of raphe calcification.';
          } else {
            procedureMode = 'TAVI Recommended (Class I, LoE A) — Transfemoral route preferred';
            examNotes = 'Age ≥ 70 years meets ESC 2025 Class I A threshold for TAVI.';
          }
        } else {
          procedureMode = 'SAVR Recommended (Class I, LoE B)';
          examNotes = 'Younger candidate (< 70 yr) with low surgical risk (< 4%) favors surgical valve durability.';
        }
      }
    } else {
      // Asymptomatic high gradient
      if (exerciseResult === 'symptoms') {
        recClass = 'Class I';
        loe = 'B';
        recommendationSummary = 'Symptoms unmasked on standardized exercise testing.';
        procedureMode = age >= 70 || surgicalRiskPercent >= 4.0 ? 'TAVI (Class I, LoE A)' : 'SAVR (Class I, LoE B)';
        examNotes = 'Patient reclassified as functionally symptomatic.';
      } else if (exerciseResult === 'bpDrop') {
        recClass = 'Class IIa';
        loe = 'C';
        recommendationSummary = 'Sustained systolic blood pressure drop > 20 mmHg during exercise testing.';
        procedureMode = age >= 70 || surgicalRiskPercent >= 4.0 ? 'TAVI (Class IIa)' : 'SAVR (Class IIa)';
        examNotes = 'Reflects inability to augment stroke volume against fixed valve obstruction.';
      } else if (lvef < 50) {
        recClass = 'Class I';
        loe = 'B';
        recommendationSummary = 'Resting LVEF < 50% without another identifiable etiology.';
        procedureMode = age >= 70 || surgicalRiskPercent >= 4.0 ? 'TAVI (Class I, LoE A)' : 'SAVR (Class I, LoE B)';
        examNotes = 'Depressed systolic function mandates early intervention to avoid irreversible myocardial fibrosis.';
      } else if (hasConcomitantSurgery) {
        recClass = 'Class I';
        loe = 'C';
        procedureMode = 'Concomitant SAVR';
        recommendationSummary = 'Undergoing cardiac surgery for other indications.';
        examNotes = 'Concomitant SAVR recommended (Class I, LoE C).';
      } else if (surgicalRiskPercent < 4.0 && lvef >= 50 && exerciseResult === 'normal') {
        // NEW 2025 RECOVERY & AVATAR
        recClass = 'Class IIa';
        loe = 'A';
        recommendationSummary = 'High-gradient severe AS with preserved EF, normal exercise testing, and low procedural risk.';
        procedureMode = age >= 70 ? 'TAVI (Class IIa, LoE A)' : 'SAVR (Class IIa, LoE A)';
        examNotes = '★ ESC 2025 Landmark Update: Early elective intervention is an established alternative to surveillance (RECOVERY & AVATAR trials).';
      } else if (meanGrad >= 60 || vMax > 5.0 || bnpElevated3x || (lvef >= 50 && lvef < 55) || rapidProgression) {
        recClass = 'Class IIa';
        loe = 'B';
        recommendationSummary = 'V-C-B-L-E Adverse Triggers met in asymptomatic severe AS.';
        procedureMode = age >= 70 ? 'TAVI (Class IIa, LoE B)' : 'SAVR (Class IIa, LoE B)';
        examNotes = 'Presence of adverse markers justifies intervention before clinical symptom onset.';
      } else {
        recClass = 'Class I';
        loe = 'C';
        recommendationSummary = 'Truly asymptomatic, normal EF, normal exercise test, and no adverse triggers.';
        procedureMode = 'Active Valve Clinic Surveillance (Review every 6 months)';
        examNotes = 'Educate patient on symptoms; avoid strenuous competitive sports; repeat echo every 6 months.';
      }
    }
  } else if (isLowFlow) {
    if (lvef < 50) {
      phenotype = 'Low-Flow Low-Gradient (Reduced EF)';
      recClass = 'Diagnostic';
      loe = 'B';
      recommendationSummary = 'Discordant low gradient with depressed LVEF and low stroke volume index (SVi ≤ 35 mL/m²).';
      procedureMode = 'Low-Dose Dobutamine Stress Echocardiography (DSE up to 20 µg/kg/min)';
      examNotes = 'Assess for flow reserve (ΔSV ≥ 20%). If AVA remains ≤ 1.0 cm² and MG rises ≥ 40 mmHg → True Severe AS (Class I B). If no reserve, obtain non-contrast CT Calcium score.';
    } else {
      phenotype = 'Low-Flow Low-Gradient (Preserved EF)';
      recClass = 'Diagnostic';
      loe = 'B';
      recommendationSummary = 'Paradoxical low-flow severe AS with preserved ejection fraction.';
      procedureMode = 'Non-Contrast Cardiac CT Calcium Score (Agatston Units)';
      examNotes = 'Confirm anatomical severity: Agatston > 2000 AU in men, > 1200 AU in women confirms true severe AS. If confirmed and symptomatic: Class IIa, LoE B.';
    }
  } else {
    phenotype = 'Normal-Flow Low-Gradient';
    recClass = 'Class III';
    loe = 'C';
    recommendationSummary = 'Low transvalvular gradient despite normal stroke volume index (SVi > 35 mL/m²).';
    procedureMode = 'Surveillance / Re-evaluate Measurement & Blood Pressure';
    examNotes = 'Usually represents MODERATE AS with continuous equation or LVOT diameter measurement discrepancies. Intervention carries futile risk (Class III).';
  }

  const generatedAnswer = `Patient Case Summary:
- Age: ${age} years | BSA: ${bsa} m²
- AVA: ${ava} cm² (Indexed: ${indexedAva} cm²/m²)
- Hemodynamics: Mean Gradient ${meanGrad} mmHg, Vmax ${vMax} m/s, SVi ${svi} mL/m², LVEF ${lvef}%
- Symptoms: ${hasSymptoms ? 'Symptomatic' : 'Asymptomatic'} (Exercise Test: ${exerciseResult})
- Surgical Risk: STS / EuroSCORE II ${surgicalRiskPercent}%

Classification & Diagnosis:
${phenotype}

ESC/EACTS 2025 Guideline Recommendation:
${recClass}, Level of Evidence ${loe}
Plan: ${procedureMode}
Rationale: ${recommendationSummary}
Exam Note: ${examNotes}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedAnswer);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4 md:p-6 shadow-xs space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider">
              CLINICAL DECISION SOLVER
            </span>
            <span className="px-2 py-0.5 bg-emerald-100 text-emerald-900 text-[10px] font-bold rounded">
              LIVE TRIAGE
            </span>
          </div>
          <h3 className="text-base font-extrabold text-slate-900 mt-0.5">
            ESC 2025 Patient Triage & Exam Prescription Engine
          </h3>
          <p className="text-xs text-slate-500">
            Adjust clinical vitals and echo parameters to generate an instant diagnosis and model exam answer
          </p>
        </div>

        <button
          type="button"
          onClick={handleCopy}
          className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 transition-colors shrink-0"
        >
          {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
          <span>{copied ? 'Copied to Clipboard' : 'Copy Case Answer'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Inputs (7 Cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="text-xs font-bold text-slate-800 uppercase tracking-wider">
            1. Patient Vitals & Echocardiography Data
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
            {/* Age */}
            <div>
              <label className="font-semibold text-slate-700 block">Age (Years):</label>
              <input
                type="number"
                min="30"
                max="95"
                value={age}
                onChange={(e) => setAge(Number(e.target.value))}
                className="w-full mt-1 p-1.5 rounded border border-slate-300 font-mono text-xs"
              />
              <span className="text-[10px] text-slate-500">2025 Cutoff: 70 yr</span>
            </div>

            {/* AVA */}
            <div>
              <label className="font-semibold text-slate-700 block">AVA (cm²):</label>
              <input
                type="number"
                step="0.05"
                min="0.3"
                max="2.0"
                value={ava}
                onChange={(e) => setAva(Number(e.target.value))}
                className="w-full mt-1 p-1.5 rounded border border-slate-300 font-mono text-xs"
              />
              <span className="text-[10px] text-slate-500">Severe ≤ 1.0</span>
            </div>

            {/* BSA */}
            <div>
              <label className="font-semibold text-slate-700 block">BSA (m²):</label>
              <input
                type="number"
                step="0.1"
                min="1.2"
                max="2.6"
                value={bsa}
                onChange={(e) => setBsa(Number(e.target.value))}
                className="w-full mt-1 p-1.5 rounded border border-slate-300 font-mono text-xs"
              />
              <span className="text-[10px] text-blue-700 font-bold font-mono">
                AVAi: {indexedAva} cm²/m²
              </span>
            </div>

            {/* Mean Gradient */}
            <div>
              <label className="font-semibold text-slate-700 block">Mean Grad (mmHg):</label>
              <input
                type="number"
                min="10"
                max="90"
                value={meanGrad}
                onChange={(e) => setMeanGrad(Number(e.target.value))}
                className="w-full mt-1 p-1.5 rounded border border-slate-300 font-mono text-xs"
              />
              <span className="text-[10px] text-slate-500">High ≥ 40, V.Severe ≥ 60</span>
            </div>

            {/* Vmax */}
            <div>
              <label className="font-semibold text-slate-700 block">Vmax (m/s):</label>
              <input
                type="number"
                step="0.1"
                min="2.0"
                max="6.5"
                value={vMax}
                onChange={(e) => setVMax(Number(e.target.value))}
                className="w-full mt-1 p-1.5 rounded border border-slate-300 font-mono text-xs"
              />
              <span className="text-[10px] text-slate-500">Severe ≥ 4.0, V.Severe &gt; 5.0</span>
            </div>

            {/* SVi */}
            <div>
              <label className="font-semibold text-slate-700 block">SVi (mL/m²):</label>
              <input
                type="number"
                min="15"
                max="60"
                value={svi}
                onChange={(e) => setSvi(Number(e.target.value))}
                className="w-full mt-1 p-1.5 rounded border border-slate-300 font-mono text-xs"
              />
              <span className="text-[10px] text-slate-500">Low-Flow ≤ 35</span>
            </div>
          </div>

          {/* LVEF Slider */}
          <div className="pt-2 text-xs">
            <label className="font-semibold text-slate-700 flex justify-between">
              <span>Left Ventricular Ejection Fraction (LVEF):</span>
              <span className="font-mono font-bold text-slate-900">{lvef}%</span>
            </label>
            <input
              type="range"
              min="20"
              max="70"
              step="1"
              value={lvef}
              onChange={(e) => setLvef(Number(e.target.value))}
              className="w-full mt-1 accent-emerald-600"
            />
            <div className="flex justify-between text-[10px] text-slate-400 font-mono">
              <span className="text-rose-600 font-bold">&lt; 50% (Class I Trigger)</span>
              <span className="text-amber-600 font-bold">50-54% (Subclinical IIa)</span>
              <span>≥ 55% (Preserved)</span>
            </div>
          </div>

          {/* Clinical Status & Modifiers */}
          <div className="pt-2 border-t border-slate-100 space-y-3 text-xs">
            <div className="text-xs font-bold text-slate-800 uppercase tracking-wider">
              2. Clinical Symptoms & Surgical Profile
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Symptom Presentation:</label>
                <div className="flex rounded border border-slate-300 overflow-hidden">
                  <button
                    type="button"
                    onClick={() => setHasSymptoms(true)}
                    className={`flex-1 py-1.5 font-semibold text-xs ${
                      hasSymptoms ? 'bg-slate-900 text-white' : 'bg-white text-slate-700'
                    }`}
                  >
                    Symptomatic (Angina/SOB)
                  </button>
                  <button
                    type="button"
                    onClick={() => setHasSymptoms(false)}
                    className={`flex-1 py-1.5 font-semibold text-xs ${
                      !hasSymptoms ? 'bg-slate-900 text-white' : 'bg-white text-slate-700'
                    }`}
                  >
                    Asymptomatic
                  </button>
                </div>
              </div>

              {!hasSymptoms && (
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Exercise Test Result:</label>
                  <select
                    value={exerciseResult}
                    onChange={(e) => setExerciseResult(e.target.value as any)}
                    className="w-full p-1.5 rounded border border-slate-300 bg-white text-xs font-medium"
                  >
                    <option value="normal">Normal Exercise Tolerance</option>
                    <option value="symptoms">Unmasked Symptoms (Class I B)</option>
                    <option value="bpDrop">SBP Fall &gt; 20 mmHg (Class IIa C)</option>
                  </select>
                </div>
              )}

              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  STS / EuroSCORE II Risk: <span className="font-mono font-bold">{surgicalRiskPercent}%</span>
                </label>
                <input
                  type="range"
                  min="0.5"
                  max="12.0"
                  step="0.5"
                  value={surgicalRiskPercent}
                  onChange={(e) => setSurgicalRiskPercent(Number(e.target.value))}
                  className="w-full accent-purple-600"
                />
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span className="font-bold text-emerald-700">&lt; 4% Low Risk</span>
                  <span className="font-bold text-purple-700">≥ 4% High Risk</span>
                </div>
              </div>

              <div className="space-y-1.5 pt-1">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isBicuspid}
                    onChange={(e) => setIsBicuspid(e.target.checked)}
                    className="rounded text-emerald-600"
                  />
                  <span className="text-slate-700">Bicuspid Aortic Valve Anatomy</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={hasConcomitantSurgery}
                    onChange={(e) => setHasConcomitantSurgery(e.target.checked)}
                    className="rounded text-emerald-600"
                  />
                  <span className="text-slate-700">Concomitant CABG / Other Surgery</span>
                </label>
              </div>
            </div>
          </div>
        </div>

        {/* Right Prescription Card (5 Cols) */}
        <div className="lg:col-span-5 bg-slate-50 border border-slate-200 rounded-xl p-4 md:p-5 flex flex-col justify-between space-y-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Diagnosis & Prescription
              </span>
              <span
                className={`text-xs font-extrabold px-2.5 py-0.5 rounded-full border ${
                  recClass === 'Class I'
                    ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                    : recClass === 'Class IIa'
                    ? 'bg-amber-100 text-amber-900 border-amber-300'
                    : recClass === 'Class IIb'
                    ? 'bg-orange-100 text-orange-900 border-orange-300'
                    : 'bg-rose-100 text-rose-900 border-rose-300'
                }`}
              >
                {recClass}, LoE {loe}
              </span>
            </div>

            <div>
              <div className="text-[10px] text-slate-500 uppercase font-mono">Phenotypic Category</div>
              <div className="font-extrabold text-slate-900 text-sm">{phenotype}</div>
            </div>

            <div className="p-3 bg-white border border-slate-200 rounded-lg space-y-1">
              <div className="text-[10px] font-bold text-slate-500 uppercase">Actionable Mode Selection</div>
              <div className="font-extrabold text-xs text-slate-900 leading-snug">
                {procedureMode}
              </div>
              <div className="text-[11px] text-slate-600 mt-1">{recommendationSummary}</div>
            </div>

            <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-lg text-xs space-y-1">
              <div className="font-bold text-blue-900 flex items-center gap-1">
                <ShieldCheck className="w-4 h-4 text-blue-600" />
                Exam Answer Commentary
              </div>
              <p className="text-slate-700 text-[11px] leading-relaxed">{examNotes}</p>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-200 text-[11px] text-slate-500 font-mono">
            Generated according to ESC/EACTS 2025 Guidelines
          </div>
        </div>
      </div>
    </div>
  );
};
