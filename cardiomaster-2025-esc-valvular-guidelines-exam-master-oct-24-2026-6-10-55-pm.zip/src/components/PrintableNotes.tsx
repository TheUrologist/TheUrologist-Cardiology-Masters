import React from 'react';
import { AS_FLOW_PHENOTYPES, AS_RECOMMENDATIONS_2025, VCBLE_MNEMONIC, HIGH_YIELD_TRAPS } from '../data/severeASData';
import { X, Printer } from 'lucide-react';

interface PrintableNotesProps {
  onClose: () => void;
}

export const PrintableNotes: React.FC<PrintableNotesProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs p-4 sm:p-6 flex justify-center items-start">
      <div className="bg-white max-w-4xl w-full rounded-2xl shadow-2xl overflow-hidden border border-slate-200">
        {/* Top Control Bar (Hidden when printed) */}
        <div className="no-print p-4 bg-slate-900 text-white flex items-center justify-between">
          <div>
            <div className="text-xs uppercase font-mono tracking-wider text-slate-400">
              Exam Revision Cheat Sheet
            </div>
            <div className="text-sm font-bold">
              ESC/EACTS 2025 Valvular Guidelines • Question 1.1 Severe AS
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => window.print()}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 rounded text-xs font-bold text-white transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print to PDF / Paper</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Body */}
        <div className="p-6 md:p-10 space-y-6 text-xs text-slate-900 font-sans">
          {/* Header Box */}
          <div className="border-2 border-slate-900 p-4 text-center space-y-1">
            <div className="text-sm font-black uppercase tracking-wider">
              MASTER SUMMARY: MANAGEMENT OF SEVERE AORTIC STENOSIS
            </div>
            <div className="text-xs text-slate-600">
              ESC/EACTS 2025 Valvular Guidelines • Cairo University Master's Exam Question 1.1
            </div>
          </div>

          {/* Section 1: Echo Criteria & Phenotypes */}
          <div className="space-y-2">
            <div className="font-bold text-xs uppercase bg-slate-100 p-1.5 border border-slate-200">
              1. ECHO DIAGNOSTIC TRIAD & 4 FLOW PHENOTYPES
            </div>
            <p className="text-[11px] text-slate-700">
              Entry Criteria: AVA ≤ 1.0 cm² or Indexed AVA ≤ 0.60 cm²/m²
            </p>
            <table className="w-full text-[11px] border border-slate-300 divide-y divide-slate-200 text-left">
              <thead className="bg-slate-50 font-bold">
                <tr>
                  <th className="p-1.5">Phenotype</th>
                  <th className="p-1.5">Hemodynamics</th>
                  <th className="p-1.5">SVi</th>
                  <th className="p-1.5">LVEF</th>
                  <th className="p-1.5">Management Protocol</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {AS_FLOW_PHENOTYPES.map((p, i) => (
                  <tr key={i}>
                    <td className="p-1.5 font-bold">{p.name}</td>
                    <td className="p-1.5 font-mono">{p.gradient}</td>
                    <td className="p-1.5 font-mono">{p.svi}</td>
                    <td className="p-1.5 font-mono">{p.lvef}</td>
                    <td className="p-1.5 text-slate-700">{p.confirmationStrategy.split('\n')[0]}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Section 2: Intervention Triggers Spectrum */}
          <div className="space-y-2">
            <div className="font-bold text-xs uppercase bg-slate-100 p-1.5 border border-slate-200">
              2. SUMMARY TABLE: ESC 2025 CLASS & LEVEL OF EVIDENCE
            </div>
            <table className="w-full text-[11px] border border-slate-300 divide-y divide-slate-200 text-left">
              <thead className="bg-slate-50 font-bold">
                <tr>
                  <th className="p-1.5">Clinical Scenario / Trigger</th>
                  <th className="p-1.5 text-center">Class</th>
                  <th className="p-1.5 text-center">LoE</th>
                  <th className="p-1.5">Key Commentary</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {AS_RECOMMENDATIONS_2025.map((r) => (
                  <tr key={r.id}>
                    <td className="p-1.5 font-semibold text-slate-800">{r.indication}</td>
                    <td className="p-1.5 text-center font-bold text-slate-900">{r.recClass}</td>
                    <td className="p-1.5 text-center font-mono font-bold">{r.loe}</td>
                    <td className="p-1.5 text-slate-600">{r.details}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Section 3: V-C-B-L-E Mnemonic & Number Line */}
          <div className="grid grid-cols-2 gap-4">
            <div className="border border-slate-300 p-3 rounded space-y-1">
              <div className="font-bold text-xs text-amber-900 uppercase">
                V-C-B-L-E Asymptomatic Triggers (Class IIa):
              </div>
              <ul className="text-[11px] space-y-1 text-slate-700">
                {VCBLE_MNEMONIC.map((m) => (
                  <li key={m.letter}>
                    <span className="font-bold font-mono text-slate-900">{m.letter}</span> — {m.title}: {m.criteria}
                  </li>
                ))}
              </ul>
            </div>

            <div className="border border-slate-300 p-3 rounded space-y-1">
              <div className="font-bold text-xs text-blue-900 uppercase">
                The Critical Number Line:
              </div>
              <ul className="text-[11px] space-y-1 font-mono text-slate-800">
                <li>• 0.25 — DVI &lt; 0.25 (Severe AS)</li>
                <li>• 0.60 — Indexed AVAi ≤ 0.60 cm²/m² (Severe)</li>
                <li>• 1.00 — Absolute AVA ≤ 1.0 cm² (Severe)</li>
                <li>• 4.00 — Vmax ≥ 4.0 m/s (Severe)</li>
                <li>• 5.00 — Vmax &gt; 5.0 m/s ("Very Severe", IIa B)</li>
                <li>• 60.0 — Mean Grad ≥ 60 mmHg ("Very Severe", IIa B)</li>
                <li>• 70.0 — Age ≥ 70 yr TAVI Cutoff (NEW 2025)</li>
              </ul>
            </div>
          </div>

          {/* Section 4: Top 3 Exam Traps */}
          <div className="border border-rose-300 bg-rose-50/40 p-3 rounded space-y-1.5 text-[11px]">
            <div className="font-bold text-rose-950 uppercase">
              TOP 3 CAIRO MASTER'S EXAM TRAPS:
            </div>
            <div>
              1. <span className="font-bold">2021 vs 2025 Age Cutoff:</span> 2021 was 75 years; ESC 2025 lowered standard TAVI cutoff to <span className="font-bold">≥ 70 years</span> (Class I, LoE A).
            </div>
            <div>
              2. <span className="font-bold">Early Surgery in Asymptomatic:</span> High-gradient + low risk + normal ET is now <span className="font-bold">Class IIa, LoE A</span> (RECOVERY & AVATAR trials), NOT strict watchful waiting.
            </div>
            <div>
              3. <span className="font-bold">Statins Myth:</span> Statins <span className="font-bold text-rose-700">DO NOT</span> halt progression (SALTIRE & ASTRONOMER trials). Futile for this indication (Class III).
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
