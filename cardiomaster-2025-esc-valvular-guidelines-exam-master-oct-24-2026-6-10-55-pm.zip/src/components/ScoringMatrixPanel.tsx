import React, { useState } from 'react';
import { AS_FLOW_PHENOTYPES, AS_RECOMMENDATIONS_2025 } from '../data/severeASData';
import { RecommendationClass } from '../types/cardiology';
import { Search, Filter, HelpCircle, Check, Copy, ExternalLink, Calculator } from 'lucide-react';

export const ScoringMatrixPanel: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<'All' | 'Symptomatic' | 'Asymptomatic' | 'Mode'>('All');
  const [classFilter, setClassFilter] = useState<RecommendationClass | 'All'>('All');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filteredRecs = AS_RECOMMENDATIONS_2025.filter((rec) => {
    const matchesSearch =
      rec.indication.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rec.details.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rec.recClass.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesCategory = categoryFilter === 'All' || rec.category === categoryFilter;
    const matchesClass = classFilter === 'All' || rec.recClass === classFilter;

    return matchesSearch && matchesCategory && matchesClass;
  });

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const getClassBadgeStyle = (recClass: RecommendationClass) => {
    switch (recClass) {
      case 'Class I':
        return 'bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-700';
      case 'Class IIa':
        return 'bg-amber-100 text-amber-800 border-amber-300 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-700';
      case 'Class IIb':
        return 'bg-orange-100 text-orange-800 border-orange-300 dark:bg-orange-950/40 dark:text-orange-300 dark:border-orange-700';
      case 'Class III':
        return 'bg-rose-100 text-rose-800 border-rose-300 dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-700';
      case 'Diagnostic':
      default:
        return 'bg-blue-100 text-blue-800 border-blue-300 dark:bg-blue-950/40 dark:text-blue-300 dark:border-blue-700';
    }
  };

  return (
    <div className="space-y-8">
      {/* Table 1: Flow & Gradient Phenotypes */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 md:p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-blue-700 uppercase tracking-wider">
                TABLE 1: CORE PHENOTYPIC CLASSIFICATION
              </span>
            </div>
            <h3 className="text-base font-extrabold text-slate-900">
              Flow & Gradient Phenotypes in Suspected Severe AS
            </h3>
          </div>
          <div className="text-xs text-slate-500 font-mono">
            SVi Cutoff: 35 mL/m² · Mean Grad Cutoff: 40 mmHg
          </div>
        </div>

        {/* High-Density Responsive Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-slate-700">
                <th className="py-2.5 px-3 font-bold">Phenotype</th>
                <th className="py-2.5 px-3 font-bold">Gradient & Velocity</th>
                <th className="py-2.5 px-3 font-bold">AVA / Index</th>
                <th className="py-2.5 px-3 font-bold">Flow (SVi)</th>
                <th className="py-2.5 px-3 font-bold">LVEF</th>
                <th className="py-2.5 px-3 font-bold">Confirmation Strategy & Protocol</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {AS_FLOW_PHENOTYPES.map((pheno, idx) => {
                let badgeClass = 'text-emerald-800 bg-emerald-50 border-emerald-200';
                if (pheno.badgeColor === 'amber') badgeClass = 'text-amber-800 bg-amber-50 border-amber-200';
                if (pheno.badgeColor === 'rose') badgeClass = 'text-rose-800 bg-rose-50 border-rose-200';

                return (
                  <tr key={idx} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-3 align-top font-bold">
                      <span className={`inline-block px-2 py-0.5 rounded border text-[11px] ${badgeClass}`}>
                        {pheno.name}
                      </span>
                    </td>
                    <td className="py-3 px-3 align-top font-mono text-[11px] text-slate-800">
                      {pheno.gradient}
                      <div className="text-slate-500">{pheno.vMax}</div>
                    </td>
                    <td className="py-3 px-3 align-top font-mono text-[11px] text-slate-800 whitespace-nowrap">
                      {pheno.ava}
                    </td>
                    <td className="py-3 px-3 align-top font-mono text-[11px] font-semibold text-slate-800">
                      {pheno.svi}
                    </td>
                    <td className="py-3 px-3 align-top font-mono text-[11px] font-semibold text-slate-800">
                      {pheno.lvef}
                    </td>
                    <td className="py-3 px-3 align-top text-slate-700">
                      <div className="whitespace-pre-line text-[11px] leading-relaxed">
                        {pheno.confirmationStrategy}
                      </div>
                      <div className="mt-1.5 text-[10px] text-slate-500 italic bg-slate-50 p-1.5 rounded border border-slate-100">
                        <span className="font-semibold text-slate-700">Exam Pitfall:</span> {pheno.pitfalls}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Quick Diagnostic Formulas Strip */}
        <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs flex flex-wrap gap-4 items-center justify-between text-slate-600">
          <div className="flex items-center gap-1.5 font-bold text-slate-800">
            <Calculator className="w-4 h-4 text-blue-600" />
            Key Formulas for the Written Exam:
          </div>
          <div className="font-mono text-[11px]">
            <span className="text-blue-700 font-bold">Continuity Eq:</span> AVA = (LVOT_Area × LVOT_VTI) / AV_VTI
          </div>
          <div className="font-mono text-[11px]">
            <span className="text-blue-700 font-bold">DVI:</span> LVOT_VTI / AV_VTI (&lt; 0.25 = Severe)
          </div>
          <div className="font-mono text-[11px]">
            <span className="text-blue-700 font-bold">SVi:</span> Stroke Volume / BSA (&le; 35 mL/m² = Low Flow)
          </div>
        </div>
      </div>

      {/* Table 2: The ESC 2025 Intervention Spectrum */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 md:p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider">
                TABLE 2: THE ESC 2025 INTERVENTION SPECTRUM
              </span>
            </div>
            <h3 className="text-base font-extrabold text-slate-900">
              Class of Recommendation & Level of Evidence Matrix
            </h3>
          </div>

          {/* Search Box */}
          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search triggers or criteria..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
            />
          </div>
        </div>

        {/* Filter Controls Bar */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
            {(['All', 'Symptomatic', 'Asymptomatic', 'Mode'] as const).map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setCategoryFilter(cat)}
                className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                  categoryFilter === cat
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
            {(['All', 'Class I', 'Class IIa', 'Class IIb', 'Class III'] as const).map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setClassFilter(c)}
                className={`px-2 py-1 rounded-md font-medium text-[11px] transition-colors ${
                  classFilter === c
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        {/* Table Rows */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-slate-700">
                <th className="py-2.5 px-3 font-bold">Category</th>
                <th className="py-2.5 px-3 font-bold">Clinical Setting & Specific Indicator</th>
                <th className="py-2.5 px-3 font-bold text-center">Class</th>
                <th className="py-2.5 px-3 font-bold text-center">LoE</th>
                <th className="py-2.5 px-3 font-bold">Key Evidence & Exam Notes</th>
                <th className="py-2.5 px-2 font-bold text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredRecs.map((rec) => (
                <tr
                  key={rec.id}
                  className={`hover:bg-slate-50/80 transition-colors ${
                    rec.isNew2025 ? 'bg-amber-50/30' : ''
                  }`}
                >
                  <td className="py-3 px-3 align-top font-bold text-slate-700">
                    <span className="text-[11px]">{rec.category}</span>
                  </td>
                  <td className="py-3 px-3 align-top text-slate-900">
                    <div className="font-bold flex items-center gap-1.5">
                      {rec.indication}
                      {rec.isNew2025 && (
                        <span className="bg-emerald-600 text-white text-[9px] font-extrabold px-1.5 py-0.2 rounded uppercase tracking-wider shrink-0">
                          NEW 2025
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-slate-600 mt-1">{rec.details}</div>
                  </td>
                  <td className="py-3 px-3 align-top text-center">
                    <span
                      className={`inline-block px-2.5 py-0.5 rounded-md border font-extrabold text-[11px] whitespace-nowrap ${getClassBadgeStyle(
                        rec.recClass
                      )}`}
                    >
                      {rec.recClass}
                    </span>
                  </td>
                  <td className="py-3 px-3 align-top text-center font-mono font-bold text-xs text-slate-800">
                    {rec.loe}
                  </td>
                  <td className="py-3 px-3 align-top text-[11px] text-slate-600">
                    {rec.citation ? (
                      <span className="text-emerald-800 font-semibold">{rec.citation}</span>
                    ) : (
                      <span>Standard ESC 2025 Guideline Benchmark</span>
                    )}
                    {rec.examMarks && (
                      <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                        Cairo Mark Weight: ~{rec.examMarks} Mark(s)
                      </div>
                    )}
                  </td>
                  <td className="py-3 px-2 align-top text-right">
                    <button
                      type="button"
                      onClick={() =>
                        handleCopy(
                          rec.id,
                          `${rec.indication} -> ${rec.recClass}, LoE ${rec.loe} (${rec.details})`
                        )
                      }
                      title="Copy bullet for your exam notes"
                      className="text-slate-400 hover:text-slate-700 p-1 rounded hover:bg-slate-100 transition-colors"
                    >
                      {copiedId === rec.id ? (
                        <Check className="w-4 h-4 text-emerald-600" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
