import { GuidelineRecommendation } from '../types/cardiology';

export interface ValvularModule {
  id: string;
  code: string;
  title: string;
  badge: string;
  description: string;
  diagnosticCriteria: { label: string; threshold: string; notes: string }[];
  recommendations: GuidelineRecommendation[];
  handDrawnSummary: string[];
  examTraps: { title: string; trap: string; solution: string }[];
}

export const MODULE_AORTIC_REGURG: ValvularModule = {
  id: 'mod-ar',
  code: 'Module 1.6 & 1.7',
  title: 'Severe Aortic Regurgitation (AR)',
  badge: 'ESC/EACTS 2025 Guideline Blueprint',
  description: 'Integrative echocardiographic grading, asymptomatic ventricular threshold triggers, and ascending aorta surgical cutoffs.',
  diagnosticCriteria: [
    { label: 'Vena Contracta Width', threshold: '> 6 mm', notes: 'High specificity for severe regurgitation in parasternal long-axis view.' },
    { label: 'Pressure Half-Time (PHT)', threshold: '< 200 ms', notes: 'Rapid diastolic pressure equalization between aorta and LV.' },
    { label: 'Regurgitant Volume (R Vol)', threshold: '≥ 60 mL/beat', notes: 'Quantitative severe threshold by PISA or volumetric calculation.' },
    { label: 'Effective Regurgitant Orifice Area (EROA)', threshold: '≥ 0.30 cm²', notes: 'Severe AR cutoff (different from MR which is 0.40 cm²).' },
    { label: 'Diastolic Flow Reversal', threshold: 'Holodiastolic reversal in descending thoracic aorta', notes: 'End-diastolic velocity > 0.2 m/s confirms hemodynamically severe AR.' },
  ],
  recommendations: [
    {
      id: 'ar-symp',
      category: 'Symptomatic',
      indication: 'Symptomatic severe AR (dyspnea, angina, heart failure)',
      details: 'Surgical aortic valve repair or replacement is recommended irrespective of LVEF.',
      recClass: 'Class I',
      loe: 'B',
      examMarks: 2,
    },
    {
      id: 'ar-asymp-ef',
      category: 'Asymptomatic',
      indication: 'Asymptomatic severe AR with resting LVEF ≤ 50%',
      details: 'Surgery recommended; delay risks irreversible left ventricular dysfunction.',
      recClass: 'Class I',
      loe: 'B',
      examMarks: 2,
    },
    {
      id: 'ar-asymp-lvesd',
      category: 'Asymptomatic',
      indication: 'Asymptomatic severe AR with LVEF > 50% but marked LV dilation: LVESD > 50 mm (or > 25 mm/m² in petite patients)',
      details: 'Surgery should be considered; prevents irreversible myocardial remodeling.',
      recClass: 'Class IIa',
      loe: 'B',
      examMarks: 2,
    },
    {
      id: 'ar-asymp-lvedd',
      category: 'Asymptomatic',
      indication: 'Asymptomatic severe AR with LVEDD > 65 mm in patients with low surgical risk',
      details: 'Surgery should be considered if progressive LV dilation is observed on serial echo.',
      recClass: 'Class IIa',
      loe: 'B',
      examMarks: 1,
    },
    {
      id: 'ar-concomitant',
      category: 'Mode',
      indication: 'Severe AR in patients undergoing CABG, surgery of ascending aorta, or other valve',
      details: 'Concomitant aortic valve replacement recommended.',
      recClass: 'Class I',
      loe: 'C',
      examMarks: 1,
    },
    {
      id: 'ar-aorta-marfan',
      category: 'Mode',
      indication: 'Ascending aorta diameter ≥ 50 mm in Marfan syndrome or bicuspid with risk factors (≥ 45 mm in high-risk family history/coarctation)',
      details: 'Aortic root/ascending aorta replacement recommended regardless of severity of AR.',
      recClass: 'Class I',
      loe: 'B',
      examMarks: 2,
    },
  ],
  handDrawnSummary: [
    'Draw 3-part layout: 1) Diagnostic Box (VC >6mm, PHT <200ms, RVol ≥60mL, EROA ≥0.30cm²)',
    '2) Asymptomatic Trigger Line: LVEF ≤ 50% (Class I) | LVESD > 50 mm or > 25 mm/m² (Class IIa) | LVEDD > 65 mm (Class IIa)',
    '3) Aorta Rule: Cutoff 55 mm general, 50 mm Marfan/Bicuspid, 45 mm very high risk',
  ],
  examTraps: [
    {
      title: 'Acute vs Chronic AR Physical Signs',
      trap: 'Candidates write that acute AR presents with wide pulse pressure, water-hammer pulse, and loud murmur.',
      solution: 'In ACUTE AR (e.g. aortic dissection or endocarditis), LV cannot dilate acutely; pulse pressure is narrow, murmur is short and soft, and premature mitral valve closure occurs. Classical peripheral signs exist only in CHRONIC AR.',
    },
    {
      title: 'Vasodilator Myth in Asymptomatic Severe AR',
      trap: 'Belief that ACE inhibitors or nifedipine delay the need for surgery in asymptomatic severe AR with normal LV function.',
      solution: 'Vasodilators have no proven disease-modifying role in asymptomatic patients with normal EF (Class III for delay of surgery). They are only used to treat hypertension.',
    },
  ],
};

export const MODULE_MITRAL_REGURG: ValvularModule = {
  id: 'mod-mr',
  code: 'Module 1.8 & 1.9',
  title: 'Mitral Regurgitation (Primary vs Secondary)',
  badge: 'ESC/EACTS 2025 Guideline Blueprint',
  description: 'Differentiating Primary (degenerative) from Secondary (functional) MR and navigating the 2026 HF/VHD Ladder (GDMT, CRT, TEER, Surgery).',
  diagnosticCriteria: [
    { label: 'Primary MR Severe EROA', threshold: '≥ 0.40 cm²', notes: 'Flail leaflet, severe chordal rupture, prolapse.' },
    { label: 'Primary MR Regurgitant Volume', threshold: '≥ 60 mL/beat', notes: 'Severe volumetric volume overload.' },
    { label: 'Secondary (Functional) MR EROA', threshold: '≥ 0.20 - 0.30 cm²', notes: 'Lower cutoff due to elliptical orifice and tethering.' },
    { label: 'Secondary MR Regurgitant Volume', threshold: '≥ 30 - 45 mL/beat', notes: 'Reflects severe prognostic threshold in heart failure.' },
    { label: 'Vena Contracta Width', threshold: '≥ 7 mm', notes: 'Confirmed in 2 orthogonal planes.' },
  ],
  recommendations: [
    {
      id: 'mr-prim-symp',
      category: 'Symptomatic',
      indication: 'Symptomatic severe Primary MR with LVEF > 30% and operable candidate',
      details: 'Surgical mitral valve repair (preferred over replacement) is recommended.',
      recClass: 'Class I',
      loe: 'B',
      examMarks: 2,
    },
    {
      id: 'mr-prim-asymp',
      category: 'Asymptomatic',
      indication: 'Asymptomatic severe Primary MR with LVEF ≤ 60% OR LVESD ≥ 40 mm (or ≥ 20 mm/m²)',
      details: 'Surgical repair recommended; note that "normal" EF in MR is higher due to low-impedance emptying into LA.',
      recClass: 'Class I',
      loe: 'B',
      examMarks: 2,
    },
    {
      id: 'mr-prim-asymp-af',
      category: 'Asymptomatic',
      indication: 'Asymptomatic severe Primary MR with preserved EF and LVESD < 40 mm, but new-onset AF or PASP > 50 mmHg at rest',
      details: 'Surgery should be considered if durable repair likelihood is > 95% in Heart Valve Center.',
      recClass: 'Class IIa',
      loe: 'B',
      examMarks: 2,
    },
    {
      id: 'mr-sec-gdmt',
      category: 'Symptomatic',
      indication: 'Secondary (functional) MR in heart failure with reduced EF',
      details: 'Optimal Guideline-Directed Medical Therapy (GDMT 4 pillars: ARNI, BB, MRA, SGLT2i) + CRT if indicated is mandatory FIRST-LINE.',
      recClass: 'Class I',
      loe: 'A',
      examMarks: 2,
    },
    {
      id: 'mr-sec-teer',
      category: 'Symptomatic',
      indication: 'Symptomatic severe Secondary MR despite optimal GDMT/CRT meeting COAPT trial criteria',
      details: 'Transcatheter Edge-to-Edge Repair (TEER / MitraClip) is recommended in Heart Team consensus (Class I / IIa A).',
      recClass: 'Class IIa',
      loe: 'A',
      examMarks: 3,
    },
    {
      id: 'mr-sec-cabg',
      category: 'Mode',
      indication: 'Severe Secondary MR undergoing surgical CABG',
      details: 'Concomitant mitral valve surgery (undersized annuloplasty) is recommended.',
      recClass: 'Class I',
      loe: 'C',
      examMarks: 1,
    },
  ],
  handDrawnSummary: [
    'Draw 2 Parallel Columns: PRIMARY MR vs SECONDARY MR',
    'Primary: Path of valve tissue -> EROA ≥0.40 -> Surgery (Repair > Replacement). Asymp cutoffs: EF ≤60%, LVESD ≥40mm.',
    'Secondary: Path of LV muscle -> EROA ≥0.20-0.30 -> GDMT 4-pillars + CRT FIRST -> If persistent: TEER (COAPT criteria) vs Surgery.',
  ],
  examTraps: [
    {
      title: 'The "Normal" LVEF Trap in Severe Primary MR',
      trap: 'Candidate writes: "LVEF is 55%, which is normal, so patient is not a surgical candidate."',
      solution: 'In severe MR, because the left ventricle ejects backwards into the low-pressure left atrium (low impedance), a resting LVEF of 55% represents OCCULT SYSTOLIC DYSFUNCTION. The surgical trigger cutoff in MR is LVEF ≤ 60% (NOT 50%).',
    },
    {
      title: 'Rushing to Surgery in Secondary MR',
      trap: 'Candidate indicates immediate mitral valve surgery for newly diagnosed severe functional MR in HFrEF.',
      solution: 'Secondary MR is a ventricular disease, not a primary leaflet problem. First step must ALWAYS be 4-pillar GDMT titration (Sacubitril/Valsartan, SGLT2i, Beta-blocker, MRA) and CRT before considering TEER or surgery.',
    },
  ],
};
