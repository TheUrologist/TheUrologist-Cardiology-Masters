/**
 * Cardiology Master's Exam & ESC 2025 Guideline Types
 */

export type RecommendationClass = 'Class I' | 'Class IIa' | 'Class IIb' | 'Class III' | 'Diagnostic';
export type LevelOfEvidence = 'A' | 'B' | 'C';

export interface GuidelineRecommendation {
  id: string;
  category: 'Symptomatic' | 'Asymptomatic' | 'Mode' | 'Diagnostic';
  indication: string;
  details: string;
  recClass: RecommendationClass;
  loe: LevelOfEvidence;
  isNew2025?: boolean;
  citation?: string;
  examMarks?: number;
}

export interface ASFlowPhenotype {
  name: string;
  badgeColor: string;
  gradient: string;
  vMax: string;
  ava: string;
  svi: string;
  lvef: string;
  confirmationStrategy: string;
  pitfalls: string;
}

export interface FlowchartNode {
  id: string;
  label: string;
  subtitle?: string;
  type: 'diagnostic' | 'decision' | 'classI' | 'classIIa' | 'classIIb' | 'classIII' | 'center';
  recClass?: RecommendationClass;
  loe?: LevelOfEvidence;
  children?: { targetId: string; conditionLabel: string }[];
}

export interface MetricNumberItem {
  value: number;
  label: string;
  unit: string;
  metricName: string;
  thresholdType: 'Severe' | 'Very Severe' | 'Dimensionless';
  clinicalMeaning: string;
  examTrapNote: string;
}

export interface HighYieldTrap {
  id: string;
  title: string;
  oldPractice: string;
  new2025Guideline: string;
  examSignificance: string;
  evidenceTrials: string;
}

export interface ExamRubricItem {
  id: string;
  section: string;
  criterion: string;
  marks: number;
}
